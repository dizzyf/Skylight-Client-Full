package net.skylightclient.skylight.util.base;

public abstract class ClientComponent {
    public final String name, id;

    public ClientComponent(String name) {
        this.name = name;
        this.id = name.replace(" ", "");
    }

    public ClientComponent(String name, String id) {
        this.name = name;
        this.id = id;
    }
}
