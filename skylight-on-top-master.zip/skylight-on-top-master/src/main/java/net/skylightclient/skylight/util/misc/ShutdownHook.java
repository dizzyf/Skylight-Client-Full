package net.skylightclient.skylight.util.misc;

import net.skylightclient.skylight.Skylight;
import net.skylightclient.skylight.util.multiplayer.Enemies;
import net.skylightclient.skylight.util.multiplayer.Friends;

public class ShutdownHook extends Thread {
    @Override
    public void run() {
        Skylight.MODULE_MANAGER.saveAll();
        Friends.save();
        Enemies.save();
    }
}
