package net.skylightclient.skylight.command;

import net.skylightclient.skylight.util.base.ClientComponent;

import java.util.ArrayList;

public abstract class Command extends ClientComponent {
    public final String description, usage;

    public Command(String name, String description, String usage) {
        super(name);

        this.description = description;
        this.usage = usage;
    }

    public abstract void onExecute(ArrayList <String> args);
}
