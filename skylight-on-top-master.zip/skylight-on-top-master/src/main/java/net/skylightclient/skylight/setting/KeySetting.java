package net.skylightclient.skylight.setting;

import net.skylightclient.skylight.util.misc.Key;

public class KeySetting extends Setting <Key> {
    public KeySetting(String name, Key value) {
        super(name, value, Type.Key);
    }

    public KeySetting(String name, String id, Key value) {
        super(name, id, value, Type.Key);
    }

    public KeySetting(String name, Integer value) {
        super(name, Key.getFromCode(value), Type.Key);
    }

    public KeySetting(String name, String id, Integer value) {
        super(name, id, Key.getFromCode(value), Type.Key);
    }
}
