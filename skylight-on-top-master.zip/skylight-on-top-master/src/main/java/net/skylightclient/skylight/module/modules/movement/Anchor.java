package net.skylightclient.skylight.module.modules.movement;

import net.skylightclient.skylight.module.Module;
import net.skylightclient.skylight.setting.BooleanSetting;

public class Anchor extends Module {
    public BooleanSetting pull = new BooleanSetting("Pull", true);

    public Anchor() {
        super("Anchor", Category.Movement);
    }
}
