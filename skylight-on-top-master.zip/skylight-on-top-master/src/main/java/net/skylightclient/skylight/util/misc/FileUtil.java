package net.skylightclient.skylight.util.misc;

import net.minecraft.client.Minecraft;
import net.skylightclient.skylight.Skylight;

public class FileUtil {
    public static final String DIR = Minecraft.getMinecraft().gameDir.getAbsolutePath() + "\\" + Skylight.MOD_NAME + "\\";
}
