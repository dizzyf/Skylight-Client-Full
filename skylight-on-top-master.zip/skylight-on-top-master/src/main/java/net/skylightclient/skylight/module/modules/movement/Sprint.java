package net.skylightclient.skylight.module.modules.movement;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.skylightclient.skylight.event.events.UpdateEvent;
import net.skylightclient.skylight.module.Module;
import net.skylightclient.skylight.setting.ModeSetting;
import org.lwjgl.input.Keyboard;

public class Sprint extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", Mode.Rage);

    public Sprint() {
        super("Sprint", Category.Movement);
        rSetting(mode);
    }

    @Override
    public void setup() {}

    @Override
    public void onEnable() {}

    @Override
    public void onDisable() {}

    @SuppressWarnings("unused") // event isn't being used when in reality it's just a placeholder
    @EventHandler
    public Listener<UpdateEvent> onUpdate = new Listener<>(event -> {
        switch ((Mode)mode.getValue()) {
            case Rage:
                mc.player.setSprinting(true);
                break;

            case Legit:
                if (Keyboard.isKeyDown(Keyboard.KEY_W))
                    mc.player.setSprinting(true);
                break;
        }
    });

    public enum Mode {
        Rage,
        Legit
    }
}
