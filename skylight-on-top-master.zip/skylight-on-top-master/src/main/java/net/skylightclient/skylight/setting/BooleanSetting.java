package net.skylightclient.skylight.setting;

public class BooleanSetting extends Setting <Boolean> {
    public BooleanSetting(String name, Boolean value) {
        super(name, value, Type.Boolean);
    }

    public BooleanSetting(String name, String id, Boolean value) {
        super(name, id, value, Type.Boolean);
    }
}
