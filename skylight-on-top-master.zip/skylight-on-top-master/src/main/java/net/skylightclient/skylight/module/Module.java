package net.skylightclient.skylight.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonReader;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.skylightclient.skylight.Skylight;
import net.skylightclient.skylight.module.modules.chat.ToggleMessages;
import net.skylightclient.skylight.setting.*;
import net.skylightclient.skylight.util.base.ClientComponent;
import net.skylightclient.skylight.util.game.ChatUtil;
import net.skylightclient.skylight.util.misc.FileUtil;
import net.skylightclient.skylight.util.misc.Key;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

public abstract class Module extends ClientComponent {
    private final ArrayList<Setting<?>> allSettings = new ArrayList<>();
    public void rSetting(Setting<?> s) {
        allSettings.add(s);
    }
    public ArrayList<Setting<?>> getAllSettings() {
        return allSettings;
    }

    public final BooleanSetting active = new BooleanSetting("Active", false);

    public final Category category;
    public final Minecraft mc = Minecraft.getMinecraft();

    public Module(String name, Category category) {
        super(name);

        this.category = category;

        active.setOnValueOverride(
                (value) -> {
                    if (value) {
                        Skylight.EVENT_MANAGER.subscribe(this);
                        onEnable();
                        if (Skylight.MODULE_MANAGER.isModuleActive(ToggleMessages.class) && isMinecraftSafe())
                            ChatUtil.sendPrefixMessage("Module " + this.id + " has been " + ChatFormatting.GREEN + "Activated!");
                    } else {
                        Skylight.EVENT_MANAGER.subscribe(this);
                        onDisable();
                        if (Skylight.MODULE_MANAGER.isModuleActive(ToggleMessages.class) && isMinecraftSafe())
                            ChatUtil.sendPrefixMessage("Module " + this.id + " has been " + ChatFormatting.RED + "Deactivated!");
                    }
                }
        );

        allSettings.add(active);
    }

    public void setup() {}
    public void onEnable() {}
    public void onDisable() {}

    public void toggle() {
        active.setValue(!active.getValue());

       if (active.getValue()) {
           Skylight.EVENT_MANAGER.subscribe(this);
           onEnable();
       }
       else {
           Skylight.EVENT_MANAGER.unsubscribe(this);
           onDisable();
       }
    }

    public boolean isMinecraftSafe() {
        return mc.world != null && mc.player != null; // Null check to prevent crashes
    }

    @Deprecated
    public void loadOld() {
        File file = new File(FileUtil.DIR + this.category + "\\" + this.id + ".json");

        if (!file.exists())
            return;


        JsonObject jObj = null;
        try {
            jObj = (JsonObject) new JsonParser().parse(new JsonReader(new FileReader(file)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        assert jObj != null;
        for (Map.Entry<String, JsonElement> entry : jObj.entrySet()) {
            Setting <?> key = null;
            try {
                key = (Setting<?>) this.getClass().getField(entry.getKey()).get(this);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                e.printStackTrace();
            }

            switch (Objects.requireNonNull(key).getClass().getName()) {
                case "BooleanSetting":
                    ((BooleanSetting)key).setValue(entry.getValue().getAsBoolean());
                    break;

                case "ColorSetting":
                case "IntegerSetting":
                    ((IntegerSetting)key).setValue(
                            entry.getValue().getAsInt()
                    );
                    break;

                case "DoubleSetting":
                    ((DoubleSetting)key).setValue(
                            entry.getValue().getAsDouble()
                    );
                    break;

                case "ModeSetting":
                    ((ModeSetting)key).setValue(
                            Enum.valueOf(
                                    ((ModeSetting)key).getValue().getClass(),
                                    entry.getValue().getAsString()
                            )
                    );
                    break;

                case "TextSetting":
                    ((TextSetting)key).setValue(
                            entry.getValue().getAsString()
                    );
                    break;
            }
        }
    }
    @Deprecated
    public void saveOld() {
        File file = new File(FileUtil.DIR + this.category + "\\" + this.id + ".json");

        JsonObject jObj = new JsonObject();

        Arrays.stream(this.getClass().getFields()).filter(
                f -> {
                    try {
                        return f.get(this) instanceof Setting <?>;
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                    return false;
                }
        ).forEach(
                f -> {
                    Setting <?> setting = null;

                    try {
                        setting = (Setting <?>) f.get(this);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                    switch (Objects.requireNonNull(setting).name.getClass().getName()) {
                        case "BooleanSetting":
                            jObj.add(setting.id, new JsonPrimitive(((BooleanSetting)setting).getValue()));
                            break;

                        case "ColorSetting":
                        case "IntegerSetting":
                            jObj.add(setting.id, new JsonPrimitive(((IntegerSetting)setting).getValue()));
                            break;

                        case "DoubleSetting":
                            jObj.add(setting.id, new JsonPrimitive(((DoubleSetting)setting).getValue()));
                            break;

                        case "ModeSetting":
                            jObj.add(setting.id, new JsonPrimitive(String.valueOf(((ModeSetting)setting).getValue())));
                            break;

                        case "TextSetting":
                            jObj.add(setting.id, new JsonPrimitive(((TextSetting)setting).getValue()));
                            break;
                    }
                }
        );

        try {
            new FileWriter(file).write(jObj.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void load() {
        File file = new File(FileUtil.DIR + this.category.toString() + "\\" + this.id + ".json");

        if (!file.exists())
            return;

        JsonObject jObj = null;

        try {
            jObj = (JsonObject)new JsonParser().parse(new JsonReader(new FileReader(file)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (Setting<?> s : allSettings) {
            switch (s.type) {
                case Boolean: {
                    ((BooleanSetting)s).setValue(jObj.get(s.id).getAsBoolean());
                    break;
                }
                case Color: {
                    ((ColorSetting)s).setValue(jObj.get(s.id).getAsInt());
                    break;
                }
                case Double: {
                    ((DoubleSetting)s).setValue(jObj.get(s.id).getAsDouble());
                    break;
                }
                case Integer: {
                    ((IntegerSetting)s).setValue(jObj.get(s.id).getAsInt());
                    break;
                }
                case Key: {
                    ((KeySetting)s).setValue(Key.getFromCode(jObj.get(s.id).getAsInt()));
                    break;
                }
                case Mode: {
                    ((ModeSetting)s).setValue(Enum.valueOf((Class <? extends Enum>)s.getValue().getClass(), jObj.get(s.id).getAsString()));
                    break;
                }
                case Parent: {
                    JsonObject object = jObj.get(s.id).getAsJsonObject();
                    ((ParentSetting)s).setValue(object.get("value").getAsBoolean());
                    ((ParentSetting)s).setOpen(object.get("open").getAsBoolean());
                    break;
                }
                case Text: {
                    ((TextSetting)s).setValue(jObj.get(s.id).getAsString());
                    break;
                }
            }
        }
    }
    public void save() {
        File file = new File(FileUtil.DIR + this.category.toString() + "\\" + this.id + ".json");
        JsonObject jObj = new JsonObject();

        for (Setting<?> s : allSettings) {
            switch (s.type) {
                case Boolean: {
                    jObj.add(s.id, new JsonPrimitive(((BooleanSetting)s).getValue()));
                    break;
                }
                case Color: {
                    jObj.add(s.id, new JsonPrimitive(((ColorSetting)s).getValue()));
                    break;
                }
                case Double: {
                    jObj.add(s.id, new JsonPrimitive(((DoubleSetting)s).getValue()));
                    break;
                }
                case Integer: {
                    jObj.add(s.id, new JsonPrimitive(((IntegerSetting)s).getValue()));
                    break;
                }
                case Key: {
                    jObj.add(s.id, new JsonPrimitive(((KeySetting)s).getValue().code));
                    break;
                }
                case Mode: {
                    jObj.add(s.id, new JsonPrimitive(String.valueOf(((ModeSetting)s).getValue())));
                    break;
                }
                case Parent: {
                    JsonObject toAdd = new JsonObject();
                    toAdd.add("value", new JsonPrimitive(((ParentSetting)s).getValue()));
                    toAdd.add("open", new JsonPrimitive(((ParentSetting)s).isOpen()));
                    jObj.add(s.id, toAdd);
                    break;
                }
                case Text: {
                    jObj.add(s.id, new JsonPrimitive(((TextSetting)s).getValue()));
                    break;
                }
            }
        }

        FileWriter fw = null;

        try {
            fw = new FileWriter(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            fw.write(jObj.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public enum Category {
        Chat,
        Combat,
        Exploit,
        Misc,
        Movement,
        Render,
        Setting
    }
}
