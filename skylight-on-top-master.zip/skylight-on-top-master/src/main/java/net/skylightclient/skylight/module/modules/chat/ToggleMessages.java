package net.skylightclient.skylight.module.modules.chat;

import net.skylightclient.skylight.module.Module;

public class ToggleMessages extends Module {
    public ToggleMessages() {
        super("Toggle Messages", Category.Chat);
//        this.active.setValue(true);
    }
}
