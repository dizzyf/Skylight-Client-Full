package net.skylightclient.skylight.util.multiplayer;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonReader;
import net.minecraft.entity.player.EntityPlayer;
import net.skylightclient.skylight.util.misc.FileUtil;

import java.io.*;
import java.util.ArrayList;
import java.util.UUID;

public class Enemies {
    public static final ArrayList<UUID> enemyUUIDs = new ArrayList<>();

    public static boolean isEnemy(EntityPlayer player) {
        if (Friends.uncheckedIsFriend(player)) return false;
        return enemyUUIDs.contains(player.entityUniqueID);
    }

    public static void load() {
        File file = new File(FileUtil.DIR + "Enemies.json");
        JsonArray jArr = new JsonArray();
        if (!file.exists()) {
            try {
                file.createNewFile();
                new FileWriter(file).write(jArr.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }

        try {
            jArr = (JsonArray)new JsonParser().parse(new JsonReader(new FileReader(file)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (JsonElement e : jArr) {
            enemyUUIDs.add(UUID.fromString(e.getAsString()));
        }
    }
    public static void save() {
        File file = new File(FileUtil.DIR + "Enemies.json");
        JsonArray jArr = new JsonArray();

        for (UUID uuid : enemyUUIDs) {
            jArr.add(new JsonPrimitive(uuid.toString()));
        }

        try {
            new FileWriter(file).write(jArr.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected static boolean uncheckedIsEnemy(EntityPlayer player) {
        return enemyUUIDs.contains(player.entityUniqueID);
    }
}
