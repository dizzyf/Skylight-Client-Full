package net.skylightclient.skylight.util.game;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

public class ChatUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void sendPrefixMessage(String message) {
        mc.ingameGUI.getChatGUI().printChatMessage(
                new TextComponentString(
                        ChatFormatting.DARK_PURPLE + "[" +
                                ChatFormatting.AQUA + "Skylight" +
                                ChatFormatting.DARK_PURPLE + "]" +
                                ChatFormatting.WHITE + message
                )
        );
    }
}
