package net.skylightclient.skylight;

import akka.event.EventBus;
import me.zero.alpine.EventManager;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.Mod;
import net.skylightclient.skylight.command.CommandManager;
import net.skylightclient.skylight.event.EventProcessor;
import net.skylightclient.skylight.module.ModuleManager;
import net.skylightclient.skylight.util.misc.ShutdownHook;
import net.skylightclient.skylight.util.multiplayer.Enemies;
import net.skylightclient.skylight.util.multiplayer.Friends;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(
        modid = Skylight.MOD_ID,
        name = Skylight.MOD_NAME,
        version = Skylight.VERSION
)
public class Skylight {
    public static final String MOD_ID = "skylight";
    public static final String MOD_NAME = "Skylight";
    public static final String VERSION = "1.0.0";

    public static final Logger LOG = LogManager.getLogger(MOD_NAME);

    public static CommandManager COMMAND_MANAGER;
    public static EventManager EVENT_MANAGER;
    public static EventProcessor EVENT_PROCESSOR;
    public static ModuleManager MODULE_MANAGER;

    @Mod.Instance(MOD_ID)
    public static Skylight INSTANCE;

    public Skylight() {
        INSTANCE = this;
    }

    @Mod.EventHandler
    public void preinit(FMLPreInitializationEvent event) {
        EVENT_MANAGER = new EventManager();
        EVENT_PROCESSOR = new EventProcessor();
        COMMAND_MANAGER = new CommandManager(); // just there so it inits itself. poor thing.
        MODULE_MANAGER = new ModuleManager();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MODULE_MANAGER.loadModules();
        Friends.load();
        Enemies.load();
        Runtime.getRuntime().addShutdownHook(new ShutdownHook());
    }

    @Mod.EventHandler
    public void postinit(FMLPostInitializationEvent event) {

    }
}
