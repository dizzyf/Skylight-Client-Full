package net.skylightclient.skylight.event;

import me.zero.alpine.type.Cancellable;

public class Event extends Cancellable {}
