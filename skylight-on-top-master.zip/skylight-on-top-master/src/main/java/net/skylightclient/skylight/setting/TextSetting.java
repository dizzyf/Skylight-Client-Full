package net.skylightclient.skylight.setting;

public class TextSetting extends Setting <String> {
    public TextSetting(String name, String value) {
        super(name, value, Type.Text);
    }

    public TextSetting(String name, String id, String value) {
        super(name, id, value, Type.Text);
    }
}
