package net.skylightclient.skylight.setting;

import net.skylightclient.skylight.util.base.ClientComponent;

import java.util.function.Consumer;

public abstract class Setting <T> extends ClientComponent {
    T value;
    public final Type type;
    private boolean child = false;
    private Consumer<T> onValueOverride = (value) -> {};

    public Setting(String name, T value, Type type) {
        super(name);

        this.value = value;
        this.type = type;
    }

    public Setting(String name, String id, T value, Type type) {
        super(name, id);

        this.value = value;
        this.type = type;
    }

    public T getValue() {
        return value;
    }
    public void setValue(T value) {
        onValueOverride.accept(value);
        this.value = value;
    }

    public Consumer<T> getOnValueOverride() {
        return onValueOverride;
    }
    public void setOnValueOverride(Consumer<T> onValueOverride) {
        this.onValueOverride = onValueOverride;
    }

    public Setting<T> asChild() {
        this.child = true;
        return this;
    }
    public boolean isChild() {
        return child;
    }

    public enum Type {
        Boolean,
        Color,
        Double,
        Integer,
        Key,
        Mode,
        Parent,
        Text
    }
}
