package net.skylightclient.skylight.util.base;

import java.util.ArrayList;

public abstract class Manager <T extends ClientComponent> {
    private final ArrayList<T> allComponents = new ArrayList<>();

    public void addComponent(T component) {
        allComponents.add(component);
    }
    public void removeComponent(T component) {
        allComponents.remove(component);
    }

    public ArrayList<T> getAllComponents() {
        return allComponents;
    }
}
