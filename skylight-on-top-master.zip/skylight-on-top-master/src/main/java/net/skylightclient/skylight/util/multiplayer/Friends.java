package net.skylightclient.skylight.util.multiplayer;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonReader;
import net.minecraft.entity.player.EntityPlayer;
import net.skylightclient.skylight.util.misc.FileUtil;

import java.io.*;
import java.util.ArrayList;
import java.util.UUID;

public class Friends {
    public static final ArrayList<UUID> friendUUIDs = new ArrayList<>();

    public static boolean isFriend(EntityPlayer player) {
        if (Enemies.uncheckedIsEnemy(player)) return false;
        return friendUUIDs.contains(player.entityUniqueID);
    }

    public static void load() {
        File file = new File(FileUtil.DIR + "Friends.json");
        JsonArray jArr = new JsonArray();
        if (!file.exists()) {
            try {
                file.createNewFile();
                new FileWriter(file).write(jArr.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }

        try {
            jArr = (JsonArray)new JsonParser().parse(new JsonReader(new FileReader(file)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (JsonElement e : jArr) {
            friendUUIDs.add(UUID.fromString(e.getAsString()));
        }
    }
    public static void save() {
        File file = new File(FileUtil.DIR + "Friends.json");
        JsonArray jArr = new JsonArray();

        for (UUID uuid : friendUUIDs) {
            jArr.add(new JsonPrimitive(uuid.toString()));
        }

        try {
            new FileWriter(file).write(jArr.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected static boolean uncheckedIsFriend(EntityPlayer player) {
        return friendUUIDs.contains(player.entityUniqueID);
    }
}
