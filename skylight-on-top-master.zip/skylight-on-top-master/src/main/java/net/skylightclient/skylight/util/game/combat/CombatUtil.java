package net.skylightclient.skylight.util.game.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.skylightclient.skylight.util.multiplayer.Friends;

import java.util.Comparator;

public class CombatUtil {
    private static Minecraft mc = Minecraft.getMinecraft();

    public static EntityPlayer findClosestTarget(float maxRange) {
        return mc.world.playerEntities.stream()
                .filter(
                        p -> p != mc.player
                ).filter(
                        p -> mc.player.getDistance(p) < maxRange
                ).filter(
                        p -> !Friends.isFriend(p)
                ).filter(
                        p -> !p.isDead
                ).min(
                        Comparator.comparing(
                                p -> mc.player.getDistance(p)
                        )
                ).orElse(null); // TODO implement enemy favoring
    }
}
