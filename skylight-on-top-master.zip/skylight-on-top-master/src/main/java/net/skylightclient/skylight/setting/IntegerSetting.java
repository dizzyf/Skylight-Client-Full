package net.skylightclient.skylight.setting;

public class IntegerSetting extends Setting <Integer> {
    public final Integer min, max;

    public IntegerSetting(String name, Integer value, Integer min, Integer max) {
        super(name, value, Type.Integer);

        this.min = min;
        this.max = max;
    }

    public IntegerSetting(String name, String id, Integer value, Integer min, Integer max) {
        super(name, id, value, Type.Integer);

        this.min = min;
        this.max = max;
    }

    @Override public void setValue(Integer value) {
        getOnValueOverride().accept(value);
        this.value = value < min ? min : value > max ? max : value;
    }
}
