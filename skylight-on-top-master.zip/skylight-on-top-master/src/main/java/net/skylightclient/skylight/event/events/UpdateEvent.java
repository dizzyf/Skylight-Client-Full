package net.skylightclient.skylight.event.events;

import net.skylightclient.skylight.event.Event;

public class UpdateEvent extends Event {}
