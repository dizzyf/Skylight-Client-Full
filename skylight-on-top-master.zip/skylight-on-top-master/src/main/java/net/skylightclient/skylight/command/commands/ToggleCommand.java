package net.skylightclient.skylight.command.commands;

import net.skylightclient.skylight.Skylight;
import net.skylightclient.skylight.command.Command;
import net.skylightclient.skylight.util.game.ChatUtil;

import java.util.ArrayList;

public class ToggleCommand extends Command {
    public ToggleCommand() {
        super("Toggle", "Toggles a Module", "toggle");
    }

    @Override
    public void onExecute(ArrayList <String> args) {
        if (args.size() < 1) {
            ChatUtil.sendPrefixMessage("Toggle Command: argument length for this command needs to be longer than 1.");
            return;
        }

        Skylight.MODULE_MANAGER.toggleModule(args.get(0));
    }
}
