package net.skylightclient.skylight.module.modules.misc;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.world.GameType;
import net.skylightclient.skylight.Skylight;
import net.skylightclient.skylight.module.Module;
import net.skylightclient.skylight.setting.BooleanSetting;
import net.skylightclient.skylight.setting.IntegerSetting;
import net.skylightclient.skylight.setting.TextSetting;

import java.util.UUID;

public class FakePlayer extends Module {
    public TextSetting displayName = new TextSetting("Name", Skylight.MOD_NAME + " v" + Skylight.VERSION);
    public IntegerSetting health = new IntegerSetting("Health", 20, 1, 36);
    public BooleanSetting usePlayerInv = new BooleanSetting("Use Player Inventory", false);

    public FakePlayer() {
        super("Fake Player", Category.Misc);
    }

    @Override
    public void onEnable() {
        if (mc.player == null || mc.player.isDead) {
            toggle();
            return;
        }

        EntityOtherPlayerMP clonedPlayer = new EntityOtherPlayerMP(mc.world, new GameProfile(UUID.randomUUID(), displayName.getValue()));

        if (usePlayerInv.getValue())
            clonedPlayer.inventory = mc.player.inventory;

        clonedPlayer.copyLocationAndAnglesFrom(mc.player);
        clonedPlayer.rotationYawHead = mc.player.rotationYawHead;
        clonedPlayer.rotationYaw = mc.player.rotationYaw;
        clonedPlayer.rotationPitch = mc.player.rotationPitch;
        clonedPlayer.setGameType(GameType.SURVIVAL);
        clonedPlayer.setHealth(health.getValue());
        mc.world.addEntityToWorld(clonedPlayer.getEntityId(), clonedPlayer);
        clonedPlayer.onLivingUpdate();
    }
}