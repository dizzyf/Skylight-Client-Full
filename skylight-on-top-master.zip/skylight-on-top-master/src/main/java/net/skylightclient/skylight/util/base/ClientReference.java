package net.skylightclient.skylight.util.base;

public class ClientReference <T> extends ClientComponent {
    private T value;

    public ClientReference(String name, T value) {
        super(name);

        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}
