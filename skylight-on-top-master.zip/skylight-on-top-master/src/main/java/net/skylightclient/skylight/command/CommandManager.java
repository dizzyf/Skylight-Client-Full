package net.skylightclient.skylight.command;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.skylightclient.skylight.command.commands.ToggleCommand;
import net.skylightclient.skylight.util.base.Manager;

import java.util.ArrayList;

@Mod.EventBusSubscriber
public class CommandManager extends Manager<Command> {
    private String prefix = "@";

    public CommandManager() {
        MinecraftForge.EVENT_BUS.register(this);

        this.addComponent(new ToggleCommand());
    }

    @SubscribeEvent
    public void onChat(ClientChatEvent event) {
        String message = event.getMessage();

        if (!message.startsWith(prefix) || message.startsWith("/"))
            return;

        event.setCanceled(true);

        Minecraft.getMinecraft().ingameGUI.getChatGUI().addToSentMessages(message);

        String[] split = message.split(" ");
        String cmdID = split[0];
        ArrayList<String> args = new ArrayList<>();

        for (int i = 1; i < split.length; i++) {
            args.add(split[i]);
        }

        for (Command c : this.getAllComponents()) {
            if (c.id.equalsIgnoreCase(cmdID)) {
                c.onExecute(args);
                break;
            }
        }
    }
}
