package net.skylightclient.skylight.module;

import net.skylightclient.skylight.Skylight;
import net.skylightclient.skylight.module.modules.chat.ToggleMessages;
import net.skylightclient.skylight.module.modules.exploit.DonkeyDesync;
import net.skylightclient.skylight.module.modules.misc.FakePlayer;
import net.skylightclient.skylight.module.modules.movement.Anchor;
import net.skylightclient.skylight.module.modules.movement.Sprint;
import net.skylightclient.skylight.util.base.Manager;
import net.skylightclient.skylight.module.modules.combat.AutoCrystal;

import java.util.ArrayList;
import java.util.Arrays;

public class ModuleManager extends Manager<Module> {
    public ModuleManager() {
        //Chat
        addComponent(new ToggleMessages());

        //Combat
        addComponent(new AutoCrystal());

        //Exploit
        addComponent(new DonkeyDesync());

        //Misc
        addComponent(new FakePlayer());

        //Movement
        addComponent(new Anchor());
        addComponent(new Sprint());

        //Render

        //Setting

    }

    public ArrayList<Module> getAllActiveComponents() {
        return new ArrayList<>(
                Arrays.asList((Module[])
                        getAllComponents().stream().filter(
                                module -> module.active.getValue()
                        ).toArray()));
    }

    public Module getModule(String id) {
        for (Module m : getAllComponents())
            if (m.id.equals(id))
                return m;

        return null;
    }
    public Module getModule(Class <? extends Module> id) {
        for (Module m : getAllComponents())
            if (m.getClass() == id)
                return m;

        return null;
    }

    public boolean isModuleActive(Class <? extends Module> id) {
        for (Module m : getAllComponents()) {
            if (m.getClass() == id && m.active.getValue())
                return true;
            break;
        }

        return false;
    }

    public void toggleModule(String id) {
        for (Module m : getAllComponents())
            if (m.id.equalsIgnoreCase(id))
                m.toggle();
    }

    public void loadModules() {
        for (Module m : getAllComponents()) {
            m.load();
            m.setup();
            if (m.active.getValue())
                m.onEnable();
        }
    }

    public void saveAll() {
        for (Module m : getAllComponents()) {
            m.save();
        }
    }
}
