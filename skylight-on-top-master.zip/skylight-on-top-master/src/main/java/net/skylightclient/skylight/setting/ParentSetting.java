package net.skylightclient.skylight.setting;

import java.util.List;

public class ParentSetting extends Setting <Boolean> {
    public final List<Setting<?>> children;
    private boolean open;

    public ParentSetting(String name, Boolean isActive, Boolean open, List<Setting<?>> children) {
        super(name, isActive, Type.Parent);

        this.open = open;
        this.children = children;
    }

    public ParentSetting(String name, String id, Boolean isActive, Boolean open, List<Setting<?>> children) {
        super(name, id, isActive, Type.Parent);

        this.open = open;
        this.children = children;
    }

    public boolean isOpen() {
        return open;
    }
    public void setOpen(Boolean open) {
        this.open = open;
    }
}
