package net.skylightclient.skylight.event;

import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.skylightclient.skylight.Skylight;
import net.skylightclient.skylight.event.events.RenderEvent;
import net.skylightclient.skylight.event.events.UpdateEvent;
//import net.skylightclient.skylight.util.base.ClientReference;
//import net.skylightclient.skylight.util.base.Manager;

//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.ArrayList;

@Mod.EventBusSubscriber
public class EventProcessor /*extends Manager<ClientReference<Object>>*/ {
    public EventProcessor() {
        MinecraftForge.EVENT_BUS.register(this);
    }

//    public void dispatch(Event event) {
//        ArrayList<ClientReference<Object>> list = getAllComponents();
//
//        for (ClientReference<Object> ref : list) {
//            Object o = ref.getValue();
//
//            for (Method m : o.getClass().getMethods()) {
//                if (
//                        m.isAnnotationPresent(EventHandler.class) &&
//                        m.getParameterCount() == 1 &&
//                        m.getParameters()[0].getType() == event.getClass()) {
//                    try {
//
//                        m.invoke(o, event);
//                    } catch (IllegalAccessException | InvocationTargetException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }
//    }

    @SubscribeEvent
    public void onUpdate(TickEvent.ClientTickEvent event) {
        Skylight.EVENT_MANAGER.post(new UpdateEvent());
    }
    @SubscribeEvent
    public void onRender(RenderWorldLastEvent event) {
        Skylight.EVENT_MANAGER.post(new RenderEvent(event.getPartialTicks()));
    }
}