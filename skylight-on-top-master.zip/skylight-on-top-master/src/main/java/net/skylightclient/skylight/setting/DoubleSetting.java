package net.skylightclient.skylight.setting;

public class DoubleSetting extends Setting <Double> {
    public final Double min, max;

    public DoubleSetting(String name, Double value, Double min, Double max) {
        super(name, value, Type.Double);

        this.min = min;
        this.max = max;
    }

    public DoubleSetting(String name, String id, Double value, Double min, Double max) {
        super(name, id, value, Type.Double);

        this.min = min;
        this.max = max;
    }

    @Override public void setValue(Double value) {
        getOnValueOverride().accept(value);
        this.value = value < min ? min : value > max ? max : value;
    }
}
