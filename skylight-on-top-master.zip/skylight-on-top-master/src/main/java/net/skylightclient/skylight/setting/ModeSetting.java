package net.skylightclient.skylight.setting;

public class ModeSetting extends Setting <Enum<?>> {
    public ModeSetting(String name, Enum<?> value) {
        super(name, value, Type.Mode);
    }

    public ModeSetting(String name, String id, Enum<?> value) {
        super(name, id, value, Type.Mode);
    }
}
