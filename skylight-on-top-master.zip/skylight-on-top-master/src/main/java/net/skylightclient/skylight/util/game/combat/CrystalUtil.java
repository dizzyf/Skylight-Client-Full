package net.skylightclient.skylight.util.game.combat;

public class CrystalUtil {
}
