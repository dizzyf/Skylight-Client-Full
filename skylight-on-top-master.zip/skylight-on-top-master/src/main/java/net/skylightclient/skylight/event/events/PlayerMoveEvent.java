package net.skylightclient.skylight.event.events;

import net.minecraft.entity.MoverType;
import net.skylightclient.skylight.event.Event;

public class PlayerMoveEvent extends Event {
    private final MoverType type;
    private final double x;
    private final double y;
    private final double z;

    public PlayerMoveEvent(MoverType type, double x, double y, double z) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public MoverType getType() {
        return type;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }
}
