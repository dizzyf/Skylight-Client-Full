package net.skylightclient.skylight.util.misc;

import net.skylightclient.skylight.Skylight;

import java.lang.reflect.InvocationTargetException;

public class ReflectionUtil {
    public static void invoke(String method, Object instance, Object... varargs) {
        try {
            instance.getClass().getMethod(method).invoke(instance, varargs);
        } catch (IllegalAccessException e) {
            Skylight.LOG.error("IllegalAccessException: " + e.getMessage());
        } catch (InvocationTargetException e) {
            Skylight.LOG.error("InvocationTargetException: " + e.getMessage());
        } catch (NoSuchMethodException e) {
            Skylight.LOG.error("NoSuchMethodException: " + e.getMessage());
        }
    }

    public static void updateField(String field, Object instance, Object newVal) {
        try {
            instance.getClass().getField(field).set(instance, newVal);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            e.printStackTrace();
        }
    }
}
