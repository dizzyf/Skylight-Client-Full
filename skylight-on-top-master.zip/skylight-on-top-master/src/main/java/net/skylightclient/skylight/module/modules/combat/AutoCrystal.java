package net.skylightclient.skylight.module.modules.combat;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.skylightclient.skylight.event.events.UpdateEvent;
import net.skylightclient.skylight.module.Module;
import net.skylightclient.skylight.setting.*;
import net.skylightclient.skylight.util.misc.Key;

import java.util.ArrayList;
import java.util.Arrays;

public class AutoCrystal extends Module {
    /////////////////////////////// Place-Specific //////////////////////////////////
    public ParentSetting place = new ParentSetting("Place", true,  true, Arrays.asList(
            placeMinDmg        = new DoubleSetting("Min Damage", "PlaceMinDamage", 5.0, 0.0, 20.0)           ,
            placeMaxSelfDmg    = new DoubleSetting("Max Self Damage", "PlaceMaxSelfDamage", 10.0, 0.0, 20.0) ,
            placeRange         = new DoubleSetting("Range", "PlaceRange", 4.0, 0.1, 6.0)                     ,
            placeTickDelay     = new IntegerSetting("Tick Delay", "PlaceTickDelay", 0, 1, 20)
    ));
    public DoubleSetting placeMinDmg     ;
    public DoubleSetting placeMaxSelfDmg ;
    public DoubleSetting placeRange      ;
    public IntegerSetting placeTickDelay ;
    /////////////////////////////// Place-Specific //////////////////////////////////

    /////////////////////////////// Break-Specific //////////////////////////////////
    public ParentSetting explode = new ParentSetting("Break", true, true, Arrays.asList(
            explodeMinDmg        = new DoubleSetting("Min Damage", "BreakMinDamage", 5.0, 0.0, 20.0)           ,
            explodeMaxSelfDmg    = new DoubleSetting("Max Self Damage", "BreakMaxSelfDamage", 10.0, 0.0, 20.0) ,
            explodeRange         = new DoubleSetting("Range", "BreakRange", 4.0, 0.1, 6.0)                     ,
            explodeTickDelay     = new IntegerSetting("Tick Delay", "BreakTickDelay", 0, 1, 20)                ,
            explodeMode          = new ModeSetting("Break Mode", BreakMode.All)
    ));
    public DoubleSetting explodeMinDmg     ;
    public DoubleSetting explodeMaxSelfDmg ;
    public DoubleSetting explodeRange      ;
    public IntegerSetting explodeTickDelay ;
    public ModeSetting explodeMode         ;
    /////////////////////////////// Break-Specific //////////////////////////////////

    /////////////////////////////// General //////////////////////////////////
    public BooleanSetting antiSuicide   = new BooleanSetting("Anti Suicide", true)                       ;
    public BooleanSetting anti32K       = new BooleanSetting("Anti 32K", false)                          ;
    public BooleanSetting allowSameTick = new BooleanSetting("Allow Break and Place in One Tick", false) ;
    public KeySetting toggleForcePlace  = new KeySetting("Force Place", Key.KEY_NONE)                         ;
    public ModeSetting damageCalc       = new ModeSetting("Damage Calc", DamageCalc.Place)                    ;
    public ModeSetting logic            = new ModeSetting("Logic", Logic.BreakPlace)                          ;
    /////////////////////////////// General //////////////////////////////////

    /////////////////////////////// Variables //////////////////////////////////
    private EntityPlayer currentTarget                   = null              ;
    private BlockPos renderPos                           = null              ;
    private int placeTicksWaited                         = 0                 ;
    private int explodeTicksWaited                       = 0                 ;
    private boolean isFaceplaceToggled                   = false             ;
    private boolean activatedThisTick                    = false             ;
    private ArrayList<EntityEnderCrystal> placedCrystals = new ArrayList<>() ;
    /////////////////////////////// Variables //////////////////////////////////

    public AutoCrystal() {
        super("Auto Crystal", Category.Combat);
    }

    @Override
    public void setup() {
        rSetting(place);
        rSetting(placeMinDmg);
        rSetting(placeMaxSelfDmg);
        rSetting(placeRange);
        rSetting(placeTickDelay);

        rSetting(explode);
        rSetting(explodeMinDmg);
        rSetting(explodeMaxSelfDmg);
        rSetting(explodeRange);
        rSetting(explodeTickDelay);

        rSetting(antiSuicide);
        rSetting(toggleForcePlace);
        rSetting(anti32K);
        rSetting(allowSameTick);
        rSetting(damageCalc);
        rSetting(logic);
    }

    @Override
    public void onEnable() {
        placeTicksWaited = 0;
        explodeTicksWaited = 0;
        currentTarget = null;
    }

    @EventHandler
    public Listener<UpdateEvent> onUpdate = new Listener<>(event -> {
        if (!isMinecraftSafe())
            return;

        switch ((Logic)logic.getValue()) {
            case PlaceBreak: {
                if (placeTicksWaited < placeTickDelay.getValue())
                    placeTicksWaited++;
                else if (place.getValue()) {
                    placeTicksWaited = 0;
                    handleCrystalPlace();
                    if (!allowSameTick.getValue())
                        return;
                }

                if (explodeTicksWaited < explodeTickDelay.getValue()) {
                    explodeTicksWaited++;
                } else if (explode.getValue()) {
                    explodeTicksWaited = 0;
                    handleCrystalExplode();
                }

                break;
            }

            case BreakPlace: {
                if (explodeTicksWaited < explodeTickDelay.getValue()) {
                    explodeTicksWaited++;
                } else if (explode.getValue()) {
                    explodeTicksWaited = 0;
                    handleCrystalExplode();
                    if (!allowSameTick.getValue())
                        return;
                }

                if (placeTicksWaited < placeTickDelay.getValue())
                    placeTicksWaited++;
                else if (place.getValue()) {
                    placeTicksWaited = 0;
                    handleCrystalPlace();
                }

                break;
            }
        }
    });

    @Override
    public void onDisable() {

    }

    public void handleCrystalPlace() {

    }

    public void handleCrystalExplode() {

    }

    public enum DamageCalc {
        Place,
        Break,
        Both
    }
    public enum Logic {
        PlaceBreak,
        BreakPlace
    }
    public enum BreakMode {
        All,
        Smart,
        Own
    }
}
