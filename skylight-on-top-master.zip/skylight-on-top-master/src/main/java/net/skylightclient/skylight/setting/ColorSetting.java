package net.skylightclient.skylight.setting;

import java.awt.*;

public class ColorSetting extends IntegerSetting {
    public ColorSetting(String name, Integer value) {
        super(name, value, 0, 255);
    }

    public Color getColor() {
        return new Color(value);
    }
}
