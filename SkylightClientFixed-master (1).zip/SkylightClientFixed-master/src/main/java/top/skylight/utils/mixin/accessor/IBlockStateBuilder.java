package top.skylight.utils.mixin.accessor;

import com.google.common.collect.ImmutableMap;
import net.minecraft.block.Block;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;

public class IBlockStateBuilder {
    public static IBlockState packetFlyState() {
        return new IBlockState() {
            @Override
            public Material getMaterial() {
                return Material.AIR;
            }

            @Override
            public boolean isFullBlock() {
                return false;
            }

            @Override
            public boolean canEntitySpawn(Entity entity) {
                return false;
            }

            @Override
            public int getLightOpacity() {
                return 100;
            }

            @Override
            public int getLightOpacity(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return 100;
            }

            @Override
            public int getLightValue() {
                return 15;
            }

            @Override
            public int getLightValue(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return 15;
            }

            @Override
            public boolean isTranslucent() {
                return false;
            }

            @Override
            public boolean useNeighborBrightness() {
                return false;
            }

            @Override
            public MapColor getMapColor(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return null;
            }

            @Override
            public IBlockState withRotation(Rotation rotation) {
                return null;
            }

            @Override
            public IBlockState withMirror(Mirror mirror) {
                return null;
            }

            @Override
            public boolean isFullCube() {
                return false;
            }

            @Override
            public boolean hasCustomBreakingProgress() {
                return false;
            }

            @Override
            public EnumBlockRenderType getRenderType() {
                return null;
            }

            @Override
            public int getPackedLightmapCoords(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return 0;
            }

            @Override
            public float getAmbientOcclusionLightValue() {
                return 0;
            }

            @Override
            public boolean isBlockNormalCube() {
                return false;
            }

            @Override
            public boolean isNormalCube() {
                return false;
            }

            @Override
            public boolean canProvidePower() {
                return true;
            }

            @Override
            public int getWeakPower(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return 0;
            }

            @Override
            public boolean hasComparatorInputOverride() {
                return false;
            }

            @Override
            public int getComparatorInputOverride(World world, BlockPos blockPos) {
                return 0;
            }

            @Override
            public float getBlockHardness(World world, BlockPos blockPos) {
                return 0;
            }

            @Override
            public float getPlayerRelativeBlockHardness(EntityPlayer entityPlayer, World world, BlockPos blockPos) {
                return 0;
            }

            @Override
            public int getStrongPower(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return 0;
            }

            @Override
            public EnumPushReaction getPushReaction() {
                return null;
            }

            @Override
            public IBlockState getActualState(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return this;
            }

            @Override
            public AxisAlignedBB getSelectedBoundingBox(World world, BlockPos blockPos) {
                return null;
            }

            @Override
            public boolean shouldSideBeRendered(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return false;
            }

            @Override
            public boolean isOpaqueCube() {
                return false;
            }

            @Nullable
            @Override
            public AxisAlignedBB getCollisionBoundingBox(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return null;
            }

            @Override
            public void addCollisionBoxToList(World world, BlockPos blockPos, AxisAlignedBB axisAlignedBB, List<AxisAlignedBB> list, @Nullable Entity entity, boolean b) {

            }

            @Override
            public AxisAlignedBB getBoundingBox(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return null;
            }

            @Override
            public RayTraceResult collisionRayTrace(World world, BlockPos blockPos, Vec3d vec3d, Vec3d vec3d1) {
                return null;
            }

            @Override
            public boolean isTopSolid() {
                return false;
            }

            @Override
            public boolean doesSideBlockRendering(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return false;
            }

            @Override
            public boolean isSideSolid(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return false;
            }

            @Override
            public boolean doesSideBlockChestOpening(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return false;
            }

            @Override
            public Vec3d getOffset(IBlockAccess iBlockAccess, BlockPos blockPos) {
                return null;
            }

            @Override
            public boolean causesSuffocation() {
                return false;
            }

            @Override
            public BlockFaceShape getBlockFaceShape(IBlockAccess iBlockAccess, BlockPos blockPos, EnumFacing enumFacing) {
                return null;
            }

            @Override
            public boolean onBlockEventReceived(World world, BlockPos blockPos, int i, int i1) {
                return false;
            }

            @Override
            public void neighborChanged(World world, BlockPos blockPos, Block block, BlockPos blockPos1) {

            }

            @Override
            public Collection<IProperty<?>> getPropertyKeys() {
                return null;
            }

            @Override
            public <T extends Comparable<T>> T getValue(IProperty<T> iProperty) {
                return null;
            }

            @Override
            public <T extends Comparable<T>, V extends T> IBlockState withProperty(IProperty<T> iProperty, V v) {
                return null;
            }

            @Override
            public <T extends Comparable<T>> IBlockState cycleProperty(IProperty<T> iProperty) {
                return null;
            }

            @Override
            public ImmutableMap<IProperty<?>, Comparable<?>> getProperties() {
                return null;
            }

            @Override
            public Block getBlock() {
                return Blocks.AIR;
            }
        }; // Makes the client think the block is nonexistent
    }
}
