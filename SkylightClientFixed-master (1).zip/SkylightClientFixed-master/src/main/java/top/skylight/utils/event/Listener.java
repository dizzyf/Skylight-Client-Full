package top.skylight.utils.event;

import top.skylight.client.SkyLight;
import top.skylight.utils.module.Module;

public class Listener<T extends Event> {
    public final Hook<T> onEvent;
    public final Module host;
    public final Class<T> eventClass;

    public Listener(Hook<T> onEvent, Module host, Class<T> eventClass) {
        this.onEvent = onEvent;
        this.host = host;
        this.eventClass = eventClass;

        SkyLight.eventBus.register(this);
    }
}
