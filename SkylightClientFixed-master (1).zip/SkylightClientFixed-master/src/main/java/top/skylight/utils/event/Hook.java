package top.skylight.utils.event;

public interface Hook<T extends Event> {
    void invoke(T event);
}
