package top.skylight.utils.command;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import top.skylight.client.commands.*;

import java.util.ArrayList;
import java.util.Arrays;

@Mod.EventBusSubscriber
public class CommandManager {
    private final ArrayList<ICommand> allCommands = new ArrayList<>();
    private final Minecraft mc = Minecraft.getMinecraft();

    public CommandManager() {
        MinecraftForge.EVENT_BUS.register(this);

        addCommand(new AllModulesCommand());
        addCommand(new FriendCommand());
        addCommand(new ToggleCommand());
    }

    public void addCommand(ICommand command) {
        allCommands.add(command);
    }

    @SubscribeEvent
    public void onClientChat(ClientChatEvent event) {
        if (event.getMessage().startsWith("=")) {
            event.setCanceled(true);
            mc.ingameGUI.getChatGUI().addToSentMessages(event.getMessage());

            String[] split = event.getMessage().split(" ");
            String command = split[0];
            String[] args = (String[]) Arrays.stream(split).filter(s -> !s.equals(split[0])).toArray();

            for (ICommand c : allCommands)
                for (String alias : c.aliases())
                    if (command.equalsIgnoreCase(alias))
                        c.execute(args);
        }
    }
}
