
package top.skylight.utils;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;

public class HWIDPastebin {
    final static ArrayList<String> final_hwid_list = get_hwids();

    public static ArrayList<String> get_hwids() {
        try {
            URL url = new URL("https://pastebin.com/raw/sG86jHWe");
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            final ArrayList<String> uuid_list = new ArrayList<>();

            String s;

            while ((s = reader.readLine()) != null) {
                uuid_list.add(s);
            }

            return uuid_list;
        } catch (Exception ignored){
            return null;
        }
    }

    public static boolean is_hwid_valid(String hwid) {
        for (String u : Objects.requireNonNull(final_hwid_list)) {
            if (u.equals(hwid)) {
                return true;
            }
        }
        return false;
    }

}
