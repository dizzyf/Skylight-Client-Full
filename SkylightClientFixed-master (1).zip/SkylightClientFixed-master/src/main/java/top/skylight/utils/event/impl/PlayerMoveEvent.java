package top.skylight.utils.event.impl;

import net.minecraft.entity.MoverType;
import top.skylight.utils.event.Event;

public class PlayerMoveEvent extends Event {
    public final MoverType type;
    public final double x, y, z;

    public PlayerMoveEvent(MoverType type, double x, double y, double z) {
        super();

        this.type = type;

        this.x = x;
        this.y = y;
        this.z = z;
    }
}
