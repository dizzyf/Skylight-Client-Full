package top.skylight.utils.event.impl;

import top.skylight.utils.event.Event;

public class UpdateEvent extends Event {
    public UpdateEvent() {
        super();
    }
}
