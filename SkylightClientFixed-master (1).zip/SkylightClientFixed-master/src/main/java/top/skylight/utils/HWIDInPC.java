package top.skylight.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/*
//bon is truly sexy
public class HWIDInPC {
	public static String getHWID() {
		try {
		String unobf = System.getProperty("user.country")
			+ System.getProperty("os.name")
			+ System.getProperty("os.arch")
			+ System.getProperty("sun.arch.data.model")
			+ System.getProperty("java.vm.version");

		MessageDigest md5 = MessageDigest.getInstance("MD5");
		md5.update(unobf.getBytes());

		StringBuffer obf = new StringBuffer();

		byte bytes[] = md5.digest();

		for(byte b : bytes) {
			String hex = Integer.toHexString(0xff & b);
			if(hex.length() == 1) {
				obf.append('0');
			}
			obf.append(hex);
		}
			return obf.toString();
		} catch (Exception fuck) {
			fuck.printStackTrace();
			return "God damnit.";
		}
	}

}

*/
public class HWIDInPC {
	private static final char[] hexArray = "0123456789ABCDEF".toCharArray();

	public static byte[] getHWID() {
		try {
			MessageDigest hash = MessageDigest.getInstance("MD5");
			StringBuilder s = new StringBuilder();
			s.append(System.getProperty("os.name"));
			s.append(System.getProperty("os.arch"));
			s.append(System.getProperty("os.version"));
			s.append(Runtime.getRuntime().availableProcessors());
			s.append(System.getenv("PROCESSOR_IDENTIFIER"));
			s.append(System.getenv("PROCESSOR_ARCHITECTURE"));
			s.append(System.getenv("PROCESSOR_ARCHITEW6432"));
			s.append(System.getenv("NUMBER_OF_PROCESSORS"));
			return hash.digest(s.toString().getBytes());
		} catch (NoSuchAlgorithmException var2) {
			throw new Error("Algorithm wasn't found.", var2);
		}
	}

	public static byte[] hexStringToByteArray(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];

		for(int i = 0; i < len; i += 2) {
			data[i / 2] = (byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
		}

		return data;
	}

	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];

		for(int j = 0; j < bytes.length; ++j) {
			int v = bytes[j] & 255;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 15];
		}

		return new String(hexChars);
	}
}



