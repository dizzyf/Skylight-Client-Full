package top.skylight.utils.friends;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.util.UUIDTypeAdapter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import top.skylight.utils.misc.FileManager;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class FriendManager {
    private static ArrayList<Friend> friends = new ArrayList<>();

    public static void addAllSavedFriends() {
        for (JsonElement element : FileManager.getFriendNameJsonArray()) {
            friends.add(getFriend(element.getAsString()));
        }
    }

    public static void addFriend(String name) {
        friends.add(getFriend(name));
    }

    public static void removeFriend(String name) {
        friends.remove(getFriend(name));
    }

    public static ArrayList<Friend> getFriends() {
        return friends;
    }

    public static Friend getFriend(String name) {
        ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(Minecraft.getMinecraft().getConnection().getPlayerInfoMap());
        NetworkPlayerInfo profile = infoMap.stream().filter(networkPlayerInfo -> networkPlayerInfo.getGameProfile().getName().equalsIgnoreCase(name)).findFirst().orElse(null);

        if (profile == null) {
            String s = requestIDs("[\"" + name + "\"]");

            if (!(s == null || s.isEmpty())) {
                JsonElement element = new JsonParser().parse(s);

                if (element.getAsJsonArray().size() != 0) {
                    try {
                        String id = element.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
                        String username = element.getAsJsonArray().get(0).getAsJsonObject().get("name").getAsString();

                        return new Friend(username, UUIDTypeAdapter.fromString(id));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            return null;
        }

        return new Friend(profile.getGameProfile().getName(), profile.getGameProfile().getId());
    }

    private static String requestIDs(String data) {
        try {
            String query = "https://api.mojang.com/profiles/minecraft";

            URL url = new URL(query);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setConnectTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestMethod("POST");

            OutputStream os = conn.getOutputStream();
            os.write(data.getBytes(StandardCharsets.UTF_8));
            os.close();

            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            String res = convertStreamToString(in);

            in.close();
            conn.disconnect();

            return res;
        } catch (Exception e) {
            return null;
        }
    }

    private static String convertStreamToString(InputStream is) {
        java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        String r = s.hasNext() ? s.next() : "/";
        return r;
    }
}