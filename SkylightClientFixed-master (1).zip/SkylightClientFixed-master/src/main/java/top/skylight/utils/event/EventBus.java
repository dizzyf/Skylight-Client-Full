package top.skylight.utils.event;

import java.util.ArrayList;

/**
 * @author Reap
 *
 * EventBus - Initiated once in the core mod, use this to dispatch events
 * inside all the registered listeners
 */

public class EventBus {
    private final ArrayList<Listener> registeredListeners = new ArrayList<>();

    public EventBus() {}

    public void register(Listener lis) {
        registeredListeners.add(lis);
    }

    public void unregister(Listener lis) {
        registeredListeners.remove(lis);
    }

    public void dispatch(Event event) {
        registeredListeners.stream()
                .filter(l -> l.host.getActive())
                .filter(l ->l.eventClass == event.getClass())
                .forEach(l -> {
                    l.onEvent.invoke(event);
                });
    }
}
