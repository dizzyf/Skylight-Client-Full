package top.skylight.utils.friends;

import java.util.UUID;

public class Friend {
    public final String username;
    public final UUID uuid;

    public Friend(String username, UUID uuid) {
        this.username = username;
        this.uuid = uuid;
    }
}
