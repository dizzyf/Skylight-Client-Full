package top.skylight.utils.event.impl;

import top.skylight.utils.event.Event;

public class ChatMessageOutgoingEvent extends Event {
    public final String message;

    public ChatMessageOutgoingEvent(String message) {
        this.message = message;
    }
}
