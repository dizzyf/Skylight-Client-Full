package top.skylight.utils.event.impl;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import top.skylight.utils.event.Event;

public class ChatMessageIncomingEvent extends Event {
    public final ClientChatReceivedEvent event;

    public ChatMessageIncomingEvent(ClientChatReceivedEvent event) {
        this.event = event;
    }
}
