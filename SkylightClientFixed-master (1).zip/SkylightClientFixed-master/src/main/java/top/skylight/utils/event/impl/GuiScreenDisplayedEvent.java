package top.skylight.utils.event.impl;

import net.minecraft.client.gui.GuiScreen;
import top.skylight.utils.event.Event;

public class GuiScreenDisplayedEvent extends Event {
    public GuiScreen screen;

    public GuiScreenDisplayedEvent(GuiScreen screenIn) {
        this.screen = screenIn;
    }
}
