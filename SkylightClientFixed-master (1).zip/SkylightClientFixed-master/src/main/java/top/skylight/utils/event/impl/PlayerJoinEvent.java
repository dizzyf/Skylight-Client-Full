package top.skylight.utils.event.impl;

import net.minecraft.entity.player.EntityPlayer;
import top.skylight.utils.event.Event;

public class PlayerJoinEvent extends Event {
    public final EntityPlayer player;

    public PlayerJoinEvent(EntityPlayer player) {
        this.player = player;
    }
}
