package top.skylight.utils.event;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import top.skylight.utils.event.impl.ChatMessageIncomingEvent;
import top.skylight.utils.event.impl.PlayerJoinEvent;
import top.skylight.utils.event.impl.RenderEvent;
import top.skylight.utils.event.impl.UpdateEvent;
import top.skylight.client.SkyLight;

/**
 * @author Reap
 *
 * EventManager - Dispatches custom versions of forge's events.
 */
@EventBusSubscriber
public class EventManager {
    public EventManager() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent public void onTickRender(TickEvent.RenderTickEvent event) {
        SkyLight.eventBus.dispatch(new RenderEvent(event));
    }

    @SubscribeEvent public void onTick(TickEvent event) {
        SkyLight.eventBus.dispatch(new UpdateEvent());
    }

    @SubscribeEvent public void onMessageIncoming(ClientChatReceivedEvent event) {
        SkyLight.eventBus.dispatch(new ChatMessageIncomingEvent(event));
    }

    @SubscribeEvent public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        SkyLight.eventBus.dispatch(new PlayerJoinEvent(event.player));
    }

    @SubscribeEvent public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        SkyLight.eventBus.dispatch(new PlayerJoinEvent(event.player));
    }
}