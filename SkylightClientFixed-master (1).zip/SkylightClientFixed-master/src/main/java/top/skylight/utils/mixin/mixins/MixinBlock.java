package top.skylight.utils.mixin.mixins;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import top.skylight.utils.mixin.accessor.IBlockStateBuilder;
import top.skylight.client.SkyLight;

@Mixin(Block.class)
public class MixinBlock {
    @Final
    @Shadow
    public Material material;

    @Redirect(method = "getActualState", at = @At("RETURN"))
    public void getActualState(IBlockState state, IBlockAccess worldIn, BlockPos pos, CallbackInfoReturnable<IBlockState> cir) {
        IBlockState packetFlyState = IBlockStateBuilder.packetFlyState();
        if (SkyLight.moduleManager.isModuleActive("PacketFly"))
            cir.setReturnValue(packetFlyState);
    }
}
