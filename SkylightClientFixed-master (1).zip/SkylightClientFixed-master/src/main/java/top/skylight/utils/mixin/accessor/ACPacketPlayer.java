package top.skylight.utils.mixin.accessor;

public interface ACPacketPlayer {
    void setOnGround(boolean onGround);

    void setX(double x);
    void setY(double y);
    void setZ(double z);

    void setYaw(float yaw);
    void setPitch(float pitch);
}
