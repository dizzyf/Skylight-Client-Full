package top.skylight.client.modules.misc;

import net.minecraft.init.Items;
import net.minecraft.item.Item;
import org.lwjgl.input.Keyboard;
import top.skylight.utils.event.Listener;
import top.skylight.utils.event.impl.UpdateEvent;
import top.skylight.utils.module.Module;
import top.skylight.utils.settings.Setting;
import top.skylight.client.SkyLight;

import java.util.Arrays;

public class FastPlace extends Module {
    private final Setting.Mode mode = new Setting.Mode("Mode", "Mode", this, (String[]) Arrays.asList(
            "Everything",
            "Crystals",
            "XP",
            "Crystals+XP"
            ).toArray()); //TODO
    private int oldTimerDelay;

    public FastPlace() {
        super("Fast Place", "FastPlace", "", false, Keyboard.KEY_NONE, Category.Misc);
    }

    @Override public void onEnable() {
        if (mc.player == null || mc.world == null) return;

        oldTimerDelay = mc.rightClickDelayTimer;

        switch (mode.getValue()) {
            case "Crystals":
                if (isHoldingItem(Items.END_CRYSTAL))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case "XP":
                if (isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case "Crystals+XP":
                if (isHoldingItem(Items.END_CRYSTAL) || isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case "Everything":
                mc.rightClickDelayTimer = 0;
        }
    }

    public Listener<UpdateEvent> onUpdate = new Listener<>(event -> {
        if (mc.player == null || mc.world == null) return;

        switch (mode.getValue()) {
            case "Crystals":
                if (isHoldingItem(Items.END_CRYSTAL))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case "XP":
                if (isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case "Crystals+XP":
                if (isHoldingItem(Items.END_CRYSTAL) || isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case "Everything":
                mc.rightClickDelayTimer = 0;
        }
    }, this, UpdateEvent.class);

    @Override public void onDisable() {
        mc.rightClickDelayTimer = oldTimerDelay;
    }

    private boolean isHoldingItem(Item item) {
        return mc.player.getHeldItemMainhand().getItem() == item || mc.player.getHeldItemOffhand().getItem() == item;
    }
}
