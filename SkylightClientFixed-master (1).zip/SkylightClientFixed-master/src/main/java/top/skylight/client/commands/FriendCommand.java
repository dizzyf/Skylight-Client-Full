package top.skylight.client.commands;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import top.skylight.utils.command.ICommand;
import top.skylight.utils.misc.ChatUtils;
import top.skylight.utils.friends.Friend;
import top.skylight.utils.friends.FriendManager;

import java.util.ArrayList;

public class FriendCommand implements ICommand {
    @Override
    public String[] aliases() {
        return new String[] {
                "friend",
                "frnd"
        };
    }

    @Override
    public String description() {
        return "Friend related things";
    }

    @Override
    public String usage() {
        return "friend/frnd/ <add|del/remove|list> <playerName (not when using list)>";
    }

    @Override
    public void execute(String[] args) {
        if (args.length < 1) {
            ChatUtils.sendErrorMessage("not enough arguments for command Friend.");
            return;
        }

        switch (args[0]) {
            case "add":
                FriendManager.addFriend(args[1]);
                break;

            case "del":
                FriendManager.removeFriend(args[1]);
                break;

            case "list":
                StringBuilder finalString = new StringBuilder();
                ArrayList<Friend> allFriends = FriendManager.getFriends();

                for (Friend f : allFriends) {
                    finalString.append(f.username).append(f == allFriends.get(allFriends.size() - 1) ? "" : ", ");
                }

                Minecraft.getMinecraft().player.sendMessage(new TextComponentString(finalString.toString()));
        }
    }
}
