package top.skylight.client.commands;

import top.skylight.client.SkyLight;
import top.skylight.utils.command.ICommand;
import top.skylight.utils.misc.ChatUtils;
import top.skylight.utils.settings.Setting;

import java.awt.*;
import java.util.Arrays;
import java.util.stream.Collectors;

public class ValueCommand implements ICommand {
    @Override
    public String[] aliases() {
        return new String[] {
                "val",
                "value"
        };
    }

    @Override
    public String description() {
        return "Sets a value to a module's setting";
    }

    @Override
    public String usage() {
        return "val/value <moduleTag> <settingTag>" +
                " \nfor mode: <0 - modeListSize-1>" +
                " \nfor boolean: <true/false>" +
                " \nfor double/integer: <newNum>" +
                " \nfor color: <colorName>";
    }

    @Override
    public void execute(String[] args) {
        if (args.length != 3) {
            ChatUtils.sendErrorMessage("Command value should always have 3 arguments.");
            return;
        }

        Setting s = SkyLight.settingsManager.getSettingByModAndTag(SkyLight.moduleManager.getModuleByTag(args[0]), args[1]);

        switch (s.getType()) {
            case Int:
                ((Setting.Int)s).setValue(Integer.parseInt(args[2]));
                return;
            case Double:
                ((Setting.Double)s).setValue(Double.parseDouble(args[2]));
                return;
            case Float:
                ((Setting.Float)s).setValue(Float.parseFloat(args[2]));
                return;
            case Bool:
                ((Setting.Bool)s).value = Boolean.parseBoolean(args[2]);
                return;
            case Color:
                ((Setting.Color)s).setValue(Color.getColor(args[2].toUpperCase()));
                return;
            case Mode:
                ((Setting.Mode)s).setValue(
                        Arrays.stream(
                        ((Setting.Mode) s).modeSwitch)
                        .filter(str -> str.equals(args[2]))
                        .collect(Collectors.joining())
                );
        }
    }
}
