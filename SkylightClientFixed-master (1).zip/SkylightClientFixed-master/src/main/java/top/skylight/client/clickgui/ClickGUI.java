package top.skylight.client.clickgui;

import net.minecraft.client.gui.GuiScreen;

public class ClickGUI extends GuiScreen {
    public ClickGUI() {

    }
}
