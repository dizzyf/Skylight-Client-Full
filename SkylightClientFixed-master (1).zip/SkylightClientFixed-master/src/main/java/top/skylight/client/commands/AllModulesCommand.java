package top.skylight.client.commands;

import top.skylight.utils.command.ICommand;
import top.skylight.utils.module.Module;
import top.skylight.client.SkyLight;
import top.skylight.utils.misc.ChatUtils;

public class AllModulesCommand implements ICommand {
    @Override
    public String[] aliases() {
        return new String[] {
                "modules"
        };
    }

    @Override
    public String description() {
        return "Shows all modules (has an active only filter).";
    }

    @Override
    public String usage() {
        return "modules <OPTIONAL> -activeOnly";
    }

    @Override
    public void execute(String[] args) {
        StringBuilder toDisp = new StringBuilder();

        if (args.length > 1) {
            ChatUtils.sendErrorMessage("Too much arguments for command modules.");
            return;
        }

        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("-activeOnly")) {
                Module[] moduleArr = SkyLight.moduleManager.getAllActiveModules();
                for (Module m : moduleArr) {
                    toDisp.append(m.getName()).append(m == moduleArr[moduleArr.length - 1] ? "" : ", ");
                }

                ChatUtils.sendInfoMessage(toDisp.toString());
            }
        }
    }
}
