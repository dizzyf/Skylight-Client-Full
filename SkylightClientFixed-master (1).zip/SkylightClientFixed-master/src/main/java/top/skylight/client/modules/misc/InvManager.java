package top.skylight.client.modules.misc;

import org.lwjgl.input.Keyboard;
import top.skylight.utils.event.Listener;
import top.skylight.utils.event.impl.UpdateEvent;
import top.skylight.utils.module.Module;
import top.skylight.utils.settings.Setting;
import top.skylight.client.SkyLight;

public class InvManager extends Module {
    private Setting.Bool replaceStrengthPots = new Setting.Bool("Replace Strength", "strengthReplace", this, true);
    private Setting.Bool throwExtraSwords = new Setting.Bool("Throw Extra Swords", "throwExtraSwords", this, true);
    private Setting.Bool refill = new Setting.Bool("Auto Refill", "AutoRefill", this, true);

    public InvManager() {
        super("Inventory Manager", "InvManager", "Sorts your Inventory automatically", false, Keyboard.KEY_NONE, Category.Misc);
    }

    public Listener<UpdateEvent> onUpdate = new Listener<>(event -> {
        if (mc.player == null || mc.world == null) return;

        if (replaceStrengthPots.value) {

        }

        if (throwExtraSwords.value) {

        }

        if (refill.value) {

        }
    }, this, UpdateEvent.class);
}
