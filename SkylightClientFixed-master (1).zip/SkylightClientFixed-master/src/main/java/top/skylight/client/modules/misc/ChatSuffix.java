package top.skylight.client.modules.misc;

import org.lwjgl.input.Keyboard;
import top.skylight.client.SkyLight;
import top.skylight.utils.event.Listener;
import top.skylight.utils.event.impl.ChatMessageOutgoingEvent;
import top.skylight.utils.module.Module;
import top.skylight.utils.settings.Setting;

import java.util.Arrays;

public class ChatSuffix extends Module {
    public Setting.Mode mode;
    public Setting.Mode seperator;

    public ChatSuffix() {
        super("Chat Suffix", "ChatSuffix", "Adds a cool suffix at the end of your messages", true, Keyboard.KEY_NONE, Category.Misc);

        SkyLight.settingsManager.register(mode = new Setting.Mode("Mode", "mode", this, (String[]) Arrays.asList(
                "Ⓢⓚⓨⓛⓘⓖⓗⓣ",
                "\uD835\uDE82\uD835\uDE94\uD835\uDEA2\uD835\uDE95\uD835\uDE92\uD835\uDE90\uD835\uDE91\uD835\uDE9D",

                "\uD835\uDD4A\uD835\uDD5C\uD835\uDD6A\uD835\uDD5D\uD835\uDD5A\uD835\uDD58\uD835\uDD59\uD835\uDD65"
        ).toArray()));
        SkyLight.settingsManager.register(seperator = new Setting.Mode("Seperator", "seperator", this, (String[]) Arrays.asList(
                " > ",
                " >> ",
                " | ",
                " (^-^) "
        ).toArray()));
    }

    public Listener<ChatMessageOutgoingEvent> onChat = new Listener<>(event -> {
        if (event.message.startsWith("=") || event.message.startsWith("/")) return; //TODO CHANGE TO PREFIX

        event.cancel();

        mc.player.sendChatMessage(event.message + seperator.getValue() + mode.getValue());
    }, this, ChatMessageOutgoingEvent.class);
}
