package top.skylight.client.commands;

import top.skylight.client.SkyLight;
import top.skylight.utils.command.ICommand;
import top.skylight.utils.misc.ChatUtils;

public class ToggleCommand implements ICommand {
    public ToggleCommand() {}

    @Override
    public String[] aliases() {
        return new String[] {
          "t",
          "tgl",
          "toggle"
        };
    }
    @Override
    public String description() {
        return "Toggles a module.";
    }
    @Override
    public String usage() {
        return "t/tgl/toggle <Module>";
    }

    @Override
    public void execute(String[] args) {
        if (args.length != 1) {
            ChatUtils.sendErrorMessage("Argument length for command toggle should always be 1.");
            return;
        }

        SkyLight.moduleManager.toggleModule(args[0]);
    }
}
