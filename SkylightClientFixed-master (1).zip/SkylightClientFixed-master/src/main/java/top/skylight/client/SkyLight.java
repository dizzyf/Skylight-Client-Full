package top.skylight.client;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLModDisabledEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.opengl.Display;
import top.skylight.utils.HWIDInPC;
import top.skylight.utils.HWIDPastebin;
import top.skylight.utils.command.CommandManager;
import top.skylight.utils.event.EventBus;
import top.skylight.utils.misc.FileManager;
import top.skylight.utils.mixin.SkyLightMixinLoader;
import top.skylight.utils.module.ModuleManager;
import top.skylight.utils.settings.SettingsManager;

@Mod(
        modid = SkyLight.MOD_ID,
        name = SkyLight.MOD_NAME,
        version = SkyLight.VERSION
)
public class SkyLight {
    public static final String MOD_ID = "skylight";
    public static final String MOD_NAME = "SkyLight";
    public static final String VERSION = "0.0.1";

    public static SkyLightMixinLoader mixinLoader;
    public static SettingsManager settingsManager;
    public static EventBus eventBus;
    public static ModuleManager moduleManager;
    public static CommandManager commandManager;

    @Mod.Instance(MOD_ID)
    public static SkyLight INSTANCE = new SkyLight();

   @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        //if we don't have the hardware id then exit the game
        if (!HWIDPastebin.is_hwid_valid(new StringBuilder().append(HWIDInPC.getHWID()).toString())) {
            System.exit(-1);
        }
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        SkyLight.mixinLoader = new SkyLightMixinLoader();
        SkyLight.mixinLoader.init();
        SkyLight.settingsManager = new SettingsManager();
        SkyLight.commandManager = new CommandManager();
        SkyLight.eventBus = new EventBus();
        SkyLight.moduleManager = new ModuleManager();
    }

    @Mod.EventHandler
    public void postinit(FMLPostInitializationEvent event) {
        Display.setTitle(MOD_NAME + " v" + VERSION);
    }

    @Mod.EventHandler
    public void close(FMLModDisabledEvent event) {
        FileManager.saveAllModules();
    }
}
