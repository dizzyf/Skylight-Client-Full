#Modules to add to SkyLight

####Combat

\> CA

\> Auto32K

\> BedAura

\> AutoCity

####Movement

\> Strafe

\> LongJump

\> ElytraFlight

\> PacketFly + Phase

####Misc

\> HoleFiller

\> PacketMine

\> AutoWither

\> Scaffold

\> DiscordRPC

####Render

\> HoleESP

\> Skeleton

\> CityESP

\> Capes

\> SkyColor

\> HitFX (SuperHero, DamageDisplay)