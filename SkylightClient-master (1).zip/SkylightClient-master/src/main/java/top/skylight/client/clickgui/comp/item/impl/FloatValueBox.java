package top.skylight.client.clickgui.comp.item.impl;

import top.skylight.utils.settings.Setting;
import top.skylight.client.clickgui.comp.item.ComponentItem;

public class FloatValueBox extends ComponentItem {
    public final float min, max;

    public float getValue() {
        return ((Setting.Float)value).getValue();
    }
    public void setValue(int newVal) {
        ((Setting.Float)value).setValue(newVal);
    }

    public boolean moving = false;

    public FloatValueBox(String name, Setting.Float value) {
        super(name, value);

        this.min = value.min;
        this.max = value.max;
    }
}
