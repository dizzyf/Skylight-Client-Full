package top.skylight.client.clickgui.comp.item.impl;

import top.skylight.utils.settings.Setting;
import top.skylight.client.clickgui.comp.item.ComponentItem;

public class DoubleValueBox extends ComponentItem {
    public final double min, max;

    public double getValue() {
        return ((Setting.Double)value).getValue();
    }
    public void setValue(int newVal) {
        ((Setting.Double)value).setValue(newVal);
    }

    public boolean moving = false;

    public DoubleValueBox(String name, Setting.Double value) {
        super(name, value);

        this.min = value.min;
        this.max = value.max;
    }
}
