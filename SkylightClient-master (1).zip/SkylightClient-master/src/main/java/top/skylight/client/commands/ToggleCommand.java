package top.skylight.client.commands;

import top.skylight.utils.command.ICommand;

public class ToggleCommand implements ICommand {
    public ToggleCommand() {}

    @Override
    public String[] aliases() {
        return new String[] {
          "t",
          "tgl",
          "toggle"
        };
    }
    @Override
    public String description() {
        return "Toggles a module.";
    }
    @Override
    public String usage() {
        return "t/tgl/toggle <Module>";
    }

    @Override
    public void execute(String[] args) {

    }
}
