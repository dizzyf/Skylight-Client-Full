package top.skylight.client.modules.misc;

import net.minecraft.init.Items;
import net.minecraft.item.Item;
import org.lwjgl.input.Keyboard;
import top.skylight.utils.event.BusAttendant;
import top.skylight.utils.event.Handler;
import top.skylight.utils.event.impl.UpdateEvent;
import top.skylight.utils.module.Module;
import top.skylight.utils.settings.Setting;
import top.skylight.client.SkyLight;

import static top.skylight.client.modules.misc.FastPlace.Mode.*;

@BusAttendant
public class FastPlace extends Module {
    private final Setting.Enum<Mode> mode = new Setting.Enum<>("Mode", "Mode", this, Everything); //TODO
    private int oldTimerDelay;

    public FastPlace() {
        super("Fast Place", "FastPlace", "", false, Keyboard.KEY_NONE, Category.Misc);
        SkyLight.INSTANCE().eventBus.register(this);
    }

    @Override public void onEnable() {
        if (mc.player == null || mc.world == null) return;

        oldTimerDelay = mc.rightClickDelayTimer;

        switch (mode.getValue()) {
            case OnlyCrystals:
                if (isHoldingItem(Items.END_CRYSTAL))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case OnlyXp:
                if (isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case Both:
                if (isHoldingItem(Items.END_CRYSTAL) || isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case Everything:
                mc.rightClickDelayTimer = 0;
        }
    }

    @Handler
    public void onUpdate(UpdateEvent event) {
        if (mc.player == null || mc.world == null) return;

        switch (mode.getValue()) {
            case OnlyCrystals:
                if (isHoldingItem(Items.END_CRYSTAL))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case OnlyXp:
                if (isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case Both:
                if (isHoldingItem(Items.END_CRYSTAL) || isHoldingItem(Items.EXPERIENCE_BOTTLE))
                    mc.rightClickDelayTimer = 0;
                else mc.rightClickDelayTimer = oldTimerDelay;
                break;
            case Everything:
                mc.rightClickDelayTimer = 0;
        }
    }

    @Override public void onDisable() {
        mc.rightClickDelayTimer = oldTimerDelay;
    }

    private boolean isHoldingItem(Item item) {
        if (mc.player.getHeldItemMainhand().getItem() == item || mc.player.getHeldItemOffhand().getItem() == item)
            return true;

        return false;
    }

    public enum Mode {
        OnlyCrystals,
        OnlyXp,
        Both,
        Everything
    }
}
