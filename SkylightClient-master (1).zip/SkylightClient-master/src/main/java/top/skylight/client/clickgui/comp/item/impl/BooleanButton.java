package top.skylight.client.clickgui.comp.item.impl;

import top.skylight.utils.settings.Setting;
import top.skylight.client.clickgui.comp.item.ComponentItem;

public class BooleanButton extends ComponentItem {
    public boolean getValue() {
        return ((Setting.Bool)value).value;
    }
    public void setValue(boolean newVal) {
        ((Setting.Bool)value).value = newVal;
    }

    public BooleanButton(String name, Setting.Bool value) {
        super(name, value);
    }
}
