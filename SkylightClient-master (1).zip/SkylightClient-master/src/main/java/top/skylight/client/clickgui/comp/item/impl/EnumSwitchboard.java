package top.skylight.client.clickgui.comp.item.impl;

import top.skylight.utils.settings.Setting;
import top.skylight.client.clickgui.comp.item.ComponentItem;

public class EnumSwitchboard<T extends Enum> extends ComponentItem {
    public T getValue() {
        return ((Setting.Enum<T>)value).getValue();
    }
    public void setValue(T newVal) {
        ((Setting.Enum<T>)value).setValue(newVal);
    }

    public EnumSwitchboard(String name, Setting.Enum<T> value) {
        super(name, value);
    }
}
