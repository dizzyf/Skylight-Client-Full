package top.skylight.client.clickgui.comp.item;

import top.skylight.utils.settings.Setting;

public abstract class ComponentItem {
    public final String name;
    public Setting value;

    public ComponentItem(String name, Setting value) {
        this.name = name;
        this.value = value;
    }
}
