package top.skylight.client.modules.ui;

import org.lwjgl.input.Keyboard;
import top.skylight.utils.event.BusAttendant;
import top.skylight.utils.event.Handler;
import top.skylight.utils.event.impl.RenderEvent;
import top.skylight.utils.module.Module;
import top.skylight.utils.settings.Setting;
import top.skylight.client.SkyLight;

@BusAttendant
public class ArrayList extends Module {
    private Setting.Int xPos = new Setting.Int("X", "XPos", this, 0, 0, 1920);
    private Setting.Int yPos = new Setting.Int("Y", "YPos", this, 0, 0, 1080);
    private Setting.Bool renderRight = new Setting.Bool("Render Right", "RenderRight", this, false);
    private Setting.Bool renderUp = new Setting.Bool("Render Up", "RenderUp", this, false);

    public ArrayList() {
        super("Array List", "ArrayList", "Renders all the active modules on your screen", true, Keyboard.KEY_NONE, Category.UI);
        SkyLight.INSTANCE().eventBus.register(this);
    }

    @Handler
    public void onRender(RenderEvent event) {

    }
}
