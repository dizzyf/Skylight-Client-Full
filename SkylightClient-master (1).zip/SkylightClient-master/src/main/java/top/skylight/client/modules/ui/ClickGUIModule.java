package top.skylight.client.modules.ui;

import org.lwjgl.input.Keyboard;
import top.skylight.utils.event.BusAttendant;
import top.skylight.utils.event.Handler;
import top.skylight.utils.event.impl.RenderEvent;
import top.skylight.utils.module.Module;
import top.skylight.client.SkyLight;
import top.skylight.client.clickgui.ClickGUI;

@BusAttendant
public class ClickGUIModule extends Module {
    private final ClickGUI gui = new ClickGUI();

    public ClickGUIModule() {
        super("Click GUI", "ClickGUI", "Opens the Click GUI", false, Keyboard.KEY_SEMICOLON, Category.UI);
    }

    @Override public void onEnable() {
        SkyLight.INSTANCE().eventBus.register(this);
    }

    @Override public void onDisable() {
        SkyLight.INSTANCE().eventBus.unregister(this);
    }

    @Handler public void onRender(RenderEvent event) {
        if (!mc.running ||
             mc.player == null ||
             mc.world == null) return;

        gui.drawScreen(mc.mouseHelper.deltaX, mc.mouseHelper.deltaY, mc.getRenderPartialTicks());
    }
}
