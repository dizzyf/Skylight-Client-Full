package top.skylight.client.clickgui;

import net.minecraft.client.gui.GuiLabel;
import net.minecraft.client.gui.GuiScreen;
import top.skylight.utils.module.Module;

import java.util.ArrayList;

public class ClickGUI extends GuiScreen {
    public ClickGUI() {
        labelList = getAllLabelsToDraw();
    }

    private ArrayList<GuiLabel> getAllLabelsToDraw() {
        ArrayList<GuiLabel> finale = new ArrayList<>();

        for (Module.Category c : Module.Category.values()) {
            GuiLabel label = new GuiLabel(mc.fontRenderer, 70, 5, 5, 5, 5, 255);
            label.addLine(c.toString());
            finale.add(label);
        }

        return finale;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
