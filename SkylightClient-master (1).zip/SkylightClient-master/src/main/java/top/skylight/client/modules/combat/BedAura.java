package top.skylight.client.modules.combat;

public class BedAura {
}
