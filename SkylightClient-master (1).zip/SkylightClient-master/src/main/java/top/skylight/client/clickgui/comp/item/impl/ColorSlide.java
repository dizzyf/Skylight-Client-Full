package top.skylight.client.clickgui.comp.item.impl;

import top.skylight.utils.settings.Setting;
import top.skylight.client.clickgui.comp.item.ComponentItem;

import java.awt.*;

public class ColorSlide extends ComponentItem {
    public Color getValue() {
        return ((Setting.Color)value).getValue();
    }
    public void setValue(Color newVal) {
        ((Setting.Color)value).setValue(newVal);
    }

    public ColorSlide(String name, Setting.Color value) {
        super(name, value);
    }
}
