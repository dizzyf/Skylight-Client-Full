package top.skylight.client;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLModDisabledEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.Mod;
import top.skylight.utils.command.CommandManager;
import top.skylight.utils.event.EventBus;
import top.skylight.utils.mixin.SkyLightMixinLoader;
import top.skylight.utils.module.ModuleManager;
import top.skylight.utils.settings.SettingsManager;
import top.skylight.utils.files.FileManager;

@Mod(
        modid = SkyLight.MOD_ID,
        name = SkyLight.MOD_NAME,
        version = SkyLight.VERSION
)
public class SkyLight {
    public static final String MOD_ID = "skylight";
    public static final String MOD_NAME = "SkyLight";
    public static final String VERSION = "0.0.1";

    public SkyLightMixinLoader mixinLoader;
    public SettingsManager settingsManager;
    public EventBus eventBus;
    public ModuleManager moduleManager;
    public CommandManager commandManager;

    /**
     * This is the instance of the mod as created by Forge. It will never be null.
     */

    public static SkyLight INSTANCE() {
        return INSTANCE;
    }

    @Mod.Instance(MOD_ID)
    private static SkyLight INSTANCE;

    public SkyLight() {}

    @Mod.EventHandler
    public void preinit(FMLPreInitializationEvent event) {
        this.mixinLoader = new SkyLightMixinLoader();
        this.mixinLoader.init();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        this.eventBus = new EventBus();
        this.moduleManager = new ModuleManager();
    }

    @Mod.EventHandler
    public void postinit(FMLPostInitializationEvent event) {
        this.settingsManager = new SettingsManager();
        this.commandManager = new CommandManager();
    }

    @Mod.EventHandler
    public void close(FMLModDisabledEvent event) {
        FileManager.saveAllModules();
    }
}
