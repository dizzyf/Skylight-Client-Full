package top.skylight.client.clickgui.comp.item.impl;

import top.skylight.utils.settings.Setting;
import top.skylight.client.clickgui.comp.item.ComponentItem;

public class IntValueBox extends ComponentItem {
    public final int min, max;

    public int getValue() {
        return ((Setting.Int)value).getValue();
    }
    public void setValue(int newVal) {
        ((Setting.Int)value).setValue(newVal);
    }

    public boolean moving = false;

    public IntValueBox(String name, Setting.Int value) {
        super(name, value);

        this.min = value.min;
        this.max = value.max;
    }
}
