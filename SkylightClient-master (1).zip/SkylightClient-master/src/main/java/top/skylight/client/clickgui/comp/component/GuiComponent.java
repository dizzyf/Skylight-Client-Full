package top.skylight.client.clickgui.comp.component;

import top.skylight.client.clickgui.comp.item.ComponentItem;

import java.util.ArrayList;

public class GuiComponent {
    public final String name, description;
    public int x, y;
    public boolean minimized = true;
    private final ArrayList<ComponentItem> itemList = new ArrayList<>();

    public GuiComponent(String name, String description, int x, int y) {
        this.name = name;
        this.description = description;

        this.x = x;
        this.y = y;
    }

    public void addItem(ComponentItem item) {
        this.itemList.add(item);
    }

    public ArrayList<ComponentItem> getItemList() {
        return itemList;
    }
}
