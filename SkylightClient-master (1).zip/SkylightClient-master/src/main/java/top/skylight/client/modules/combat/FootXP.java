package top.skylight.client.modules.combat;

import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayer;
import org.lwjgl.input.Keyboard;
import top.skylight.utils.event.BusAttendant;
import top.skylight.utils.event.Handler;
import top.skylight.utils.event.impl.PacketEvent;
import top.skylight.utils.module.Module;
import top.skylight.utils.mixin.accessor.ACPacketPlayer;

@BusAttendant
public class FootXP extends Module {
    public FootXP() {
        super("Foot XP", "FootXP", "", false, Keyboard.KEY_NONE, Category.Combat);
    }

    @Handler
    public void onPacket(PacketEvent.Send event) {
        if (!(event.getPacket() instanceof CPacketPlayer)) return;
        if (mc.player.getHeldItemMainhand().getItem() != Items.EXPERIENCE_BOTTLE) return;

        CPacketPlayer packetPlayer = (CPacketPlayer) event.getPacket();
        ((ACPacketPlayer)packetPlayer).setPitch(90.0f);
    }
}
