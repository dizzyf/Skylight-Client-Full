package top.skylight.utils.module;

import net.minecraft.client.Minecraft;

import javax.annotation.Nullable;

/**
 * @author Reap
 */
public abstract class Module {
    private final String name, tag, description;
    public String getName() {
        return name;
    }
    public String getTag() {
        return tag;
    }
    public String getDescription() {
        return description;
    }
    private final boolean isActive;
    public boolean getActive() {
        return isActive;
    }
    private final int bind;
    public int getBind() {
        return bind;
    }
    private final Category category;
    public Category getCategory() {
        return category;
    }

    public final Minecraft mc = Minecraft.getMinecraft();

    public Module(String name, String tag, @Nullable String description, boolean isActive, int bind, Category category) {
        this.name = name;
        this.tag = tag;
        this.isActive = isActive;
        this.bind = bind;
        this.category = category;
        this.description = description != null ? description : "No Description.";
    }

    public enum Category {
        Combat      ,
        Movement    ,
        Exploits    ,
        Misc        ,
        Render      ,
        UI          ,
    }

    public void onEnable() {}
    public void onDisable() {}
}
