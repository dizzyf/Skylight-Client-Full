package top.skylight.utils.event.impl;

import net.minecraftforge.fml.common.gameevent.TickEvent;
import top.skylight.utils.event.Event;

public class RenderEvent extends Event {
    public final TickEvent.RenderTickEvent event;

    public RenderEvent(TickEvent.RenderTickEvent event) {
        this.event = event;
    }

    @Override
    public void cancel() {
        super.cancel();
        event.setCanceled(true);
    }
}
