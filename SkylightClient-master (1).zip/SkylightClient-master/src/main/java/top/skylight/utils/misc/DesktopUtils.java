package top.skylight.utils.misc;

public class DesktopUtils {
    public static void writeErrorLog(String error) {

    }
}
