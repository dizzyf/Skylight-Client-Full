package top.skylight.utils.settings;

import top.skylight.utils.module.Module;
import top.skylight.client.SkyLight;

public abstract class Setting {
    private final String name, tag;
    private final Module host;
    private final Type type;

    public Setting(String name, String tag, Module host, Type type) {
        this.name = name;
        this.tag = tag;

        this.host = host;

        this.type = type;

        SkyLight.INSTANCE().settingsManager.register(this);
    }

    public String getName() {
        return name;
    }
    public String getTag() {
        return tag;
    }
    public Module getHost() {
        return host;
    }
    public Type getType() {
        return type;
    }

    public static class Int extends Setting {
        private int value;
        public final int min, max;

        public Int(String name, String tag, Module host, int value, int min, int max) {
            super(name, tag, host, Type.Int);

            this.value = value;
            this.min = min;
            this.max = max;
        }

        public int getValue() {
            return value;
        }
        public void setValue(int newVal) {
            this.value = newVal; //TODO clipping by min / max
        }

    }
    public static class Double extends Setting {
        private double value;
        public double min, max;

        public Double(String name, String tag, Module host, double value, double min, double max) {
            super(name, tag, host, Type.Double);

            this.value = value;
            this.min = min;
            this.max = max;
        }

        public double getValue() {
            return value;
        }
        public void setValue(double newVal) {
            this.value = newVal; //TODO clipping by min / max
        }
    }
    public static class Float extends Setting {
        private float value;
        public float min, max;

        public Float(String name, String tag, Module host, float value, float min, float max) {
            super(name, tag, host, Type.Float);

            this.value = value;
            this.min = min;
            this.max = max;
        }

        public float getValue() {
            return value;
        }
        public void setValue(float newVal) {
            this.value = newVal; //TODO clipping by min / max
        }
    }
    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, String tag, Module host, boolean value) {
            super(name, tag, host, Type.Bool);

            this.value = value;
        }
    }
    public static class Color extends Setting {
        private java.awt.Color value;

        public Color(String name, String tag, Module host, java.awt.Color value) {
            super(name, tag, host, Type.Color);

            this.value = value;
        }

        public java.awt.Color getValue() {
            return value;
        }
        public void setValue(java.awt.Color newVal) {
            this.value = newVal;
        }
    }
    public static class Enum<T extends java.lang.Enum> extends Setting {
        private T value;

        public Enum(String name, String tag, Module host, T value) {
            super(name, tag, host, Type.Enum);

            this.value = value;
        }

        public T getValue() {
            return value;
        }
        public void setValue(T newVal) {
            this.value = newVal;
        }
    }

    public enum Type {
        Int,
        Double,
        Float,
        Bool,
        Color,
        Enum
    }
}
