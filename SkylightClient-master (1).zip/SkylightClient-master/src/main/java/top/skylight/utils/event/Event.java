package top.skylight.utils.event;

public abstract class Event {
    private boolean canceled = false;
    public boolean isCanceled() {
        return canceled;
    }
    public void cancel() {
        this.canceled = true;
    }

    public Event() {}
}
