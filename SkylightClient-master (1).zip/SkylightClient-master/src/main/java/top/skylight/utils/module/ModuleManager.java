package top.skylight.utils.module;

import top.skylight.client.modules.combat.FootXP;
import top.skylight.client.modules.exploits.MultiTask;
import top.skylight.client.modules.misc.FastPlace;
import top.skylight.client.modules.ui.ClickGUIModule;

import java.util.ArrayList;

/**
 * @author Reap
 */
public class ModuleManager {
    private ArrayList<Module> allModules = new ArrayList<>();

    public ModuleManager() {
        //Combat
        addModule(new FootXP());

        //Movement


        //Exploits
        addModule(new MultiTask());

        //Misc
        addModule(new FastPlace());

        //Render


        //UI
        addModule(new top.skylight.client.modules.ui.ArrayList());
        addModule(new ClickGUIModule());

    }

    private void addModule(Module module) {
        allModules.add(module);
    }

    public Module getModuleByTag(String tag) {
        for (Module m : allModules) {
            if (m.getTag().equalsIgnoreCase(tag)) return m;
        }

        return null;
    }

    public ArrayList<Module> getAllModules() {
        return allModules;
    }

    public Module[] getAllActiveModules() {
        return (Module[]) allModules.stream().filter(Module::getActive).toArray();
    }

    public boolean isModuleActive(String tag) {
        for (Module mod : allModules) {
            if (mod.getTag().equalsIgnoreCase(tag)) return mod.getActive();
        }

        return false;
    }
}
