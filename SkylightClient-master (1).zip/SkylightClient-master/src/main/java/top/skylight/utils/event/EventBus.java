package top.skylight.utils.event;

import top.skylight.utils.module.Module;

import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * @author Reap
 *
 * EventBus - Initiated once in the core mod, use this to dispatch events (will invoke all methods that are tagged with {@link Handler}
 * inside all the registered classes
 */

public class EventBus {
    /**
     * all the registered classes (registered at {@see EventBus.java#register})
     */
    private final ArrayList<Object> registeredObjects = new ArrayList<>();

    public EventBus() {}

    /**
     * tries to add the input object to the registeredObjects ArrayList (input module must include {@link BusAttendant})
     *
     * @param obj input object
     */
    public void register(Object obj) {
        if (!obj.getClass().isAnnotationPresent(BusAttendant.class)) return;

        registeredObjects.add(obj);
    }

    /**
     * attempts to remove the input object from the registeredmods ArrayList
     *
     * @param obj input object
     */
    public void unregister(Object obj) {
        registeredObjects.remove(obj);
    }

    /**
     * dispatches the input event to all the classes in the registeredClasses ArrayList
     *
     * @param event the Event dispatched with all it's extra info
     */
    public void dispatch(Event event) {
        for (Object obj : registeredObjects) {
            // checking for if obj is a Module and if it's active.
            if (obj instanceof Module) {
                if (!((Module) obj).getActive()) {
                    return;
                }
            }

            /*
               checking for all of object's methods and executing handler ones.
             */
            for (Method m : obj.getClass().getMethods()) {
                if (m.getParameterCount() != 1) return;
                if (m.getParameters()[0].getType() == event.getClass()) return;
                if (!m.isAnnotationPresent(Handler.class)) return;

                try {
                    if (!event.isCanceled()) m.invoke(obj, event);
                } catch (Exception ignored) {}
            }
        }
    }
}
