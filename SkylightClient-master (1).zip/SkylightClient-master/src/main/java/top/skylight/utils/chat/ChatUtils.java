package top.skylight.utils.chat;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class ChatUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void sendInfoMessage(String message) {
        mc.player.sendMessage(new TextComponentString(
                TextFormatting.GREEN + "[" +
                TextFormatting.AQUA + "SkyLight" +
                TextFormatting.GREEN + "]" +
                " " + message
        ));
    }
    public static void sendToggleMessage(String modName, boolean enable) {
        if (enable) sendInfoMessage(TextFormatting.GREEN + modName + " was enabled!");
        else sendInfoMessage(TextFormatting.RED + modName + " was disabled!");
    }
    public static void sendErrorMessage(String error) {
        sendInfoMessage(
                TextFormatting.RED + "ERROR: " +
                TextFormatting.WHITE + error
        );
    }
}
