package top.skylight.utils.files;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import net.minecraft.client.Minecraft;
import top.skylight.utils.module.Module;
import top.skylight.utils.settings.Setting;
import top.skylight.client.SkyLight;
import top.skylight.utils.misc.DesktopUtils;

import java.io.*;

public class FileManager {
    public static final String baseDir = Minecraft.getMinecraft().gameDir.getAbsolutePath() + "\\Skylight\\";

    public static JsonObject getJsonObjectForModule(Module module) {
        try {
            return (JsonObject) new JsonParser().parse(new JsonReader(new FileReader(baseDir + "Modules\\" + module.getCategory().toString() + "\\" + module.getTag() + ".json")));
        } catch (Exception e) {
            return null;
        }
    }

    public static JsonArray getFriendNameJsonArray() {
        try {
            return (JsonArray) new JsonParser().parse(new JsonReader(new FileReader(baseDir + "Friends\\FriendList.json")));
        } catch (Exception e) {
            return new JsonArray();
        }
    }

    public static boolean saveModule(Module module) {
        JsonObject newModSettings = new JsonObject();

        for (Setting setting : SkyLight.INSTANCE().settingsManager.getSettingsByMod(module)) {
            switch (setting.getType()) {
                case Int:
                    newModSettings.add(setting.getName(), new JsonPrimitive(String.valueOf(((Setting.Int) setting).getValue())));
                    break;

                case Double:
                    newModSettings.add(setting.getName(), new JsonPrimitive(String.valueOf(((Setting.Double) setting).getValue())));
                    break;

                case Float:
                    newModSettings.add(setting.getName(), new JsonPrimitive(String.valueOf(((Setting.Float) setting).getValue())));
                    break;

                case Bool:
                    newModSettings.add(setting.getName(), new JsonPrimitive(String.valueOf(((Setting.Bool) setting).value)));
                    break;

                case Color:
                    newModSettings.add(setting.getName(), new JsonPrimitive(String.valueOf(((Setting.Color) setting).getValue())));
                    break;

                case Enum:
                    newModSettings.add(setting.getName(), new JsonPrimitive(String.valueOf(((Setting.Enum) setting).getValue())));
                    break;

                default:
                    DesktopUtils.writeErrorLog("Saving Settings Failed: " + setting.getName() + "'s Type is invalid.");
                    return false;
            }
        }

        return saveFile(
                newModSettings.getAsString(),

                baseDir +
                     "Modules\\" +
                     module.getCategory().toString() +
                     "\\" + module.getTag() +
                     ".json",

      "Saving Settings for Module " +
                     module.getName() +
                     "Failed"
        );
    }

    public static void saveAllModules() {
        for (Module m : SkyLight.INSTANCE().moduleManager.getAllActiveModules()) {
            saveModule(m);
        }
    }

    private static boolean saveFile(String content, String path, String errorMessagePrefix) {
        File file = new File(path);

        file.delete();
        try {
            file.createNewFile();
        } catch (IOException e) {
            DesktopUtils.writeErrorLog(errorMessagePrefix + ": Could not create A new File.");
            return false;
        }

        FileWriter writer;
        try {
            writer = new FileWriter(file.getAbsolutePath());
        } catch (IOException e) {
            DesktopUtils.writeErrorLog(errorMessagePrefix + ": FileWriter Initialization failed.");
            return false;
        }

        try {
            writer.write(content);
        } catch (IOException e) {
            DesktopUtils.writeErrorLog(errorMessagePrefix + ": Writing failed.");
            return false;
        }

        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            DesktopUtils.writeErrorLog(errorMessagePrefix + ": Writer Flushing failed.");
            return false;
        }

        return true;
    }
}
