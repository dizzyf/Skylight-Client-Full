package top.skylight.utils.mixin.mixins;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.MoverType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.skylight.utils.event.impl.ChatMessageOutgoingEvent;
import top.skylight.utils.event.impl.PlayerMoveEvent;
import top.skylight.client.SkyLight;

@Mixin(value = EntityPlayerSP.class, priority = 25105)
public class MixinEntityPlayerSP {
    @Inject(method = "move", at = @At("INVOKE"))
    public void move(MoverType type, double x, double y, double z, CallbackInfo ci) {
        SkyLight.INSTANCE().eventBus.dispatch(new PlayerMoveEvent(type, x, y, z));
    }

    @Inject(method = "sendChatMessage", at = @At("INVOKE"))
    public void sendChatMessage(String message, CallbackInfo ci) {
        ChatMessageOutgoingEvent event = new ChatMessageOutgoingEvent(message);

        SkyLight.INSTANCE().eventBus.dispatch(event);

        if (event.isCanceled()) {
            ci.cancel();
        }
    }
}
