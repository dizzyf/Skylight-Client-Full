package top.skylight.utils.settings;

import top.skylight.utils.module.Module;

import java.util.ArrayList;
import java.util.Arrays;

public class SettingsManager {
    private final ArrayList<Setting> allSettings = new ArrayList<>();

    public SettingsManager() {}

    public void register(Setting setting) {
        allSettings.add(setting);
    }

    public ArrayList<Setting> getSettingsByMod(Module mod) {
        return new ArrayList<>(Arrays.asList((Setting[]) allSettings.stream().filter(s -> s.getHost() == mod).toArray()));
    }
}
