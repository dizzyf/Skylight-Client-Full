package top.skylight.utils.event;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import top.skylight.utils.event.impl.RenderEvent;
import top.skylight.utils.event.impl.UpdateEvent;
import top.skylight.client.SkyLight;

/**
 * @author Reap
 *
 * EventManager - Dispatches custom versions of forge's events.
 */
@EventBusSubscriber
public class EventManager {
    public EventManager() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    /**
     * onTickRender - dispatches skylight's RenderEvent.
     * @param event unused
     */
    @SubscribeEvent
    public void onTickRender(TickEvent.RenderTickEvent event) {
        SkyLight.INSTANCE().eventBus.dispatch(new RenderEvent(event));
    }
    @SubscribeEvent
    public void onTick(TickEvent event) {
        SkyLight.INSTANCE().eventBus.dispatch(new UpdateEvent());
    }
}