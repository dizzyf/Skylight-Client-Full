package top.skylight.utils.command;

public interface ICommand {
    String[] aliases();
    String description();
    String usage();

    void execute(String[] args);
}
