package net.skylightclient.skylight.api.module

import net.minecraft.client.Minecraft
import net.skylightclient.skylight.api.setting.*
import net.skylightclient.skylight.utils.misc.Key
import net.skylightclient.skylight.utils.misc.SkylightTessellator

/**
 * @author Reap
 * @since 11/15/2020
 */
abstract class Module(
        val name: String,
        val id: String,
        val description: String,
        val category: ModuleCategory
) {
    /**
     * @return the default mc instance
     */
    val mc: Minecraft = Minecraft.getMinecraft()
    val tessellator by lazy { SkylightTessellator.INSTANCE }

    /**
     * @return true if we are safe to use the minecraft functions, false if not
     */
    fun isNullSafe(): Boolean =
            mc.player != null && mc.world != null

    /**
     * all the settings for the module
     */
    val settingList: ArrayList<Setting<*>> = ArrayList()

    fun getSettingByName(name: String): Setting<*>? {
        for (setting in settingList)
            if (setting.name.equals(name, true))
                return setting

        return null
    }

    /**
     * @return the value of the boolean setting called active present on every module
     */
    var active by register(
            BooleanSetting(
                    "Active",
                    "$id.$name",
                    false
            ).also {
                it.onValueOverride = { it1 ->
                    if (it1) {
                        onEnable()
                    } else {
                        onDisable()
                    }
                }
            }
    )

    /**
     * @return the value of the key setting called bind present on every module
     */
    var bind by register(
            KeySetting(
                    "Bind",
                    "$id.$name",
                    Key.KEY_NONE.code
            )
    )

    /**
     * @param T: the type of the setting we are registering
     * @param s: the setting we are registering
     * @return s after we registered it
     */
    fun <T : Setting<*>> register(s: T): T = s.also {
        settingList.add(it)
    }

    fun save() {
//        TODO("make a saving / loading logic.")
    }

    fun load() {
//        TODO("make a saving / loading logic.")
    }

    /**
     * a special function in every module, activating once when we start the game
     */
    open fun onSetup() {}

    /**
     * a special function in every module, activating once when we set active to true
     */
    open fun onEnable() {}

    /**
     * a special function in every module, activating once when we set active to false
     */
    open fun onDisable() {}
}