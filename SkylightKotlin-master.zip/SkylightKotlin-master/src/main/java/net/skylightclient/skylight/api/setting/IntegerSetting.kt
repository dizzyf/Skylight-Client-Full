package net.skylightclient.skylight.api.setting

class IntegerSetting(
        name: String,
        id: String,
        value: Int,
        min: Int,
        max: Int
) : NumberSetting <Int> (
        name,
        id,
        value,
        min,
        max
)