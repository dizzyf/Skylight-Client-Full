package net.skylightclient.skylight.api.module

import net.skylightclient.skylight.impl.module.*
import net.skylightclient.skylight.impl.module.chat.*
import net.skylightclient.skylight.impl.module.combat.*
import net.skylightclient.skylight.impl.module.misc.*
import net.skylightclient.skylight.impl.module.movement.*
import net.skylightclient.skylight.impl.module.render.*
import net.skylightclient.skylight.utils.misc.Initializable

import java.util.stream.Stream

/**
 * @author Reap
 * @since 11/15/2020
 */

object ModuleManager : Initializable {
    /**
     * all the registered modules
     */
    val modules by lazy {arrayListOf(
            // Chat
            Suffix,

            // Combat
            Aura,
            RocanAura(),

            // Exploit

            // Misc
            AutoRickRoll,
            FakePlayer,

            // Movement
            Sprint,

            // Player

            // Render
            Fullbright

            // UI
    )}

    fun activeModules(): Stream<Module> =
            modules.stream()
                    .filter {
                        it.active
                    }

    /**
     * toggles a module by ID
     *
     * @param id: ID of the module we want to toggle
     */
    fun toggle(id: String) {
        for (module in modules)
            if (id.equals(module.id, true))
                module.active = !module.active
    }

    fun getModule(id: String): Module {
        for (module in modules)
            if (id.equals(module.id, true))
                return module

        return DummyModule
    }

    fun getModule(clazz: Class<Module>): Module {
        for (module in modules)
            if (clazz.isAssignableFrom(module::class.java))
                return module

        return DummyModule
    }

    fun saveModules() {
        for (module: Module in modules)
            module.save()
    }

    override fun initialize() {
        for (module: Module in modules)
            try {
                module.onSetup()
                module.load()
            } catch (ignored: ExceptionInInitializerError) {}
    }
}