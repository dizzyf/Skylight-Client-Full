package net.skylightclient.skylight.utils.misc

interface Initializable {
    fun initialize()
}