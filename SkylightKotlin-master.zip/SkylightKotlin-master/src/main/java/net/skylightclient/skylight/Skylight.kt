package net.skylightclient.skylight

import net.skylightclient.skylight.api.command.CommandManager
import net.skylightclient.skylight.api.event.EventProcessor
import net.skylightclient.skylight.api.module.ModuleManager
import net.skylightclient.skylight.impl.gui.clickgui.ClickGUI
import net.skylightclient.skylight.utils.players.Friends

object Skylight {
    fun preinit() {}

    fun init() {
        CommandManager.initialize()
        EventProcessor.initialize()
        ModuleManager.initialize()
        Friends.initialize()
        Runtime.getRuntime().addShutdownHook(ShutdownHook())
    }

    fun postinit() {
        ClickGUI.initialize()
    }
}