package net.skylightclient.skylight.api.event

/**
 * @author Reap
 * @since 11/15/2020
 */
open class Event {
    /**
     * determines if we should cancel the event
     */
    open var cancelled: Boolean = false
}