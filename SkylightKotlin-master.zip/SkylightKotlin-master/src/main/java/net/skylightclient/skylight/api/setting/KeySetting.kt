package net.skylightclient.skylight.api.setting

import net.skylightclient.skylight.utils.misc.Key

class KeySetting(
        name: String,
        id: String,
        value: Int
) : Setting<Int>(
        name,
        id,
        value
) {
    fun getKey(): Key {
        return Key.fromCode(value)
    }

    fun setValueByKey(key: Key) {
        value = key.code
    }

    fun getKeyName(): String {
        return getKey().name
    }
}