package net.skylightclient.skylight.impl.command

import com.mojang.realmsclient.gui.ChatFormatting
import net.skylightclient.skylight.api.command.ICommand
import net.skylightclient.skylight.api.module.ModuleManager
import net.skylightclient.skylight.utils.game.ChatUtils

object ToggleCommand : ICommand {
    override fun aliases(): ArrayList<String> = arrayListOf(
            "t",
            "tgl",
            "toggle"
    )

    override fun description(): String = "Toggles a Module"

    override fun usage(): String = "${aliases()} <module>"

    override fun exec(args: List<String>) =
            if (args.size < 2)
                ChatUtils.sendChatMessage("Command ${args[0]} requires you to use at least 1 argument.")
            else {
                ModuleManager.toggle(args[1])
                ChatUtils.sendChatMessage(
                        "${ if (ModuleManager.getModule(args[1]).active) 
                            "${ ChatFormatting.GREEN }Enabled " else "${ ChatFormatting.RED }Disabled " } " +
                            "${ ChatFormatting.AQUA }${ args[1][0].toUpperCase() + args[1].substring(1) }!")
            }
}