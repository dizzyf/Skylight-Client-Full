package net.skylightclient.skylight.api.module

enum class ModuleCategory {
    Chat,
    Combat,
    Exploit,
    Misc,
    Movement,
    Player,
    Render,
    UI
}