package net.skylightclient.skylight.utils.misc

import com.google.gson.*
import com.google.gson.stream.JsonReader
import net.minecraft.client.Minecraft
import java.io.File
import java.io.FileReader
import java.io.IOException

object FileUtil {
    private val mc = Minecraft.getMinecraft()
    private val path = "${mc.gameDir.absolutePath}\\Skylight\\"

    fun getJsonObjectByPath(pth: String): JsonObject {
        val file = File(path+pth)
        if (!file.exists()) {
            file.createNewFile()
            return JsonObject()
        }

        return JsonParser().parse(JsonReader(FileReader(file))) as JsonObject
    }

    fun <T : JsonElement> getJsonElementByPath(pth: String): T? {
        val file = File(path+pth)
        if (!file.exists()) {
            try {
                file.createNewFile()
            } catch (ignored: IOException) {}
            return null
        }

        return JsonParser().parse(JsonReader(FileReader(file))) as T
    }

    fun getJsonArrayByPath(pth: String): JsonArray {
        val file = File(path+pth)
        if (!file.exists()) {
            file.createNewFile()
            return JsonArray()
        }

        return JsonParser().parse(JsonReader(FileReader(file))) as JsonArray
    }
}