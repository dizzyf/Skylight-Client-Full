package net.skylightclient.skylight.utils.game

import net.minecraft.client.Minecraft
import net.minecraft.util.text.TextComponentString
import net.minecraft.util.text.TextFormatting

object ChatUtils {
    val mc = Minecraft.getMinecraft()

    fun sendChatMessage(txt: String) =
            mc.player.sendMessage(TextComponentString(
                    "${TextFormatting.DARK_AQUA} [" +
                         "${TextFormatting.AQUA}Skylight" +
                         "${TextFormatting.DARK_AQUA}]" +
                         "${TextFormatting.WHITE} $txt"
            ))
}