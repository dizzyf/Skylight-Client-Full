package net.skylightclient.skylight.api.setting

class ParentSetting(
        name: String,
        id: String,
        value: Boolean,

        var isOpen: Boolean,
        val children: List<Setting<*>>
) : Setting <Boolean>(
        name,
        id,
        value
)