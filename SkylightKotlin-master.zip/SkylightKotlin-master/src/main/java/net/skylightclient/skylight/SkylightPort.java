package net.skylightclient.skylight;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.skylightclient.skylight.api.mixin.SkylightMixinLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(
        modid = SkylightPort.MOD_ID,
        name = SkylightPort.MOD_NAME,
        version = SkylightPort.VERSION,
        clientSideOnly = true
)
public class SkylightPort {
    public static final String MOD_ID = "skylight";
    public static final String MOD_NAME = "skylight";
    public static final String VERSION = "1.0.0";

    public static final Logger log = LogManager.getLogger(MOD_NAME);

    public static SkylightMixinLoader mixinLoader;

    @Mod.Instance
    public static SkylightPort INSTANCE;

    public SkylightPort() {
        INSTANCE = this;
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        mixinLoader = new SkylightMixinLoader();
        Skylight.INSTANCE.preinit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Skylight.INSTANCE.init();
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        Skylight.INSTANCE.postinit();
    }
}
