package net.skylightclient.skylight.impl.gui.clickgui.component.impl.setting

import net.skylightclient.skylight.api.setting.IntegerSetting

class IntegerSlider(
        value: IntegerSetting,
        posX: Double,
        posY: Double,
        width: Double,
        height: Double
) : NumberSlider<IntegerSetting>(
        value,
        posX,
        posY,
        width,
        height
)