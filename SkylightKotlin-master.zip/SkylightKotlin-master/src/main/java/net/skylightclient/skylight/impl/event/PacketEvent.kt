package net.skylightclient.skylight.impl.event

import net.minecraft.network.Packet
import net.skylightclient.skylight.api.event.Event

open class PacketEvent(val packet: Packet<*>) : Event() {
    class Write(packet: Packet<*>) : PacketEvent(packet)
    class Read(packet: Packet<*>) : PacketEvent(packet)
}