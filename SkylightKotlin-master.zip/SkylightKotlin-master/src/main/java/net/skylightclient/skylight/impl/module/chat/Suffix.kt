package net.skylightclient.skylight.impl.module.chat

import net.minecraft.network.play.client.CPacketChatMessage
import net.skylightclient.skylight.api.event.EventListener
import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.api.setting.ModeSetting
import net.skylightclient.skylight.impl.event.PacketEvent

object Suffix : Module(
        "Suffix",
        "Suffix",
        "Adds a cool suffix to your message. ",
        ModuleCategory.Chat
) {
    var mode by register(
            ModeSetting(
                    "Mode",
                    "Suffix.Mode",
                    arrayListOf(
                            "Regular",
                            fontHephaestus("Hephaestus"),
                            fontCircle("Circle")
                    )
            )
    )

    val onPacket = EventListener(
            PacketEvent.Write::class.java,
            {
                if (it.packet is CPacketChatMessage) {
                    it.cancelled = true
                    mc.player.sendChatMessage(
                            when (mode) {
                                fontHephaestus("Hephaestus") -> fontHephaestus(it.packet.message)
                                fontCircle("Circle") -> fontCircle(it.packet.message)
                                else -> it.packet.message
                            }
                    )
                    return@EventListener false
                }

                true
            },
            this
    )

    fun fontHephaestus(args: String): String =
            args.replace("a", "\u1d00")
                .replace("b", "\u0299")
                .replace("c", "\u1d04")
                .replace("d", "\u1d05")
                .replace("e", "\u1d07")
                .replace("f", "\u0493")
                .replace("g", "\u0262")
                .replace("h", "\u029c")
                .replace("i", "\u026a")
                .replace("j", "\u1d0a")
                .replace("k", "\u1d0b")
                .replace("l", "\u029f")
                .replace("m", "\u1d0d")
                .replace("n", "\u0274")
                .replace("o", "\u1d0f")
                .replace("p", "\u1d18")
                .replace("q", "\u01eb")
                .replace("r", "\u0280")
                .replace("s", "\u0455")
                .replace("t", "\u1d1b")
                .replace("u", "\u1d1c")
                .replace("v", "\u1d20")
                .replace("w", "\u1d21")
                .replace("x", "\u0445")
                .replace("y", "\u028f")
                .replace("z", "\u1d22")

    fun fontCircle(args: String): String =
            args.replace("a", "\u24B6")
                .replace("b", "\u24B7")
                .replace("c", "\u24B8")
                .replace("d", "\u24B9")
                .replace("e", "\u24BA")
                .replace("f", "\u24BB")
                .replace("g", "\u24BC")
                .replace("h", "\u24BD")
                .replace("i", "\u24BE")
                .replace("j", "\u24BF")
                .replace("k", "\u24C0")
                .replace("l", "\u24C1")
                .replace("m", "\u24C2")
                .replace("n", "\u24C3")
                .replace("o", "\u24C4")
                .replace("p", "\u24C5")
                .replace("q", "\u24C6")
                .replace("r", "\u24C7")
                .replace("s", "\u24C8")
                .replace("t", "\u24C9")
                .replace("u", "\u24CA")
                .replace("v", "\u24CB")
                .replace("w", "\u24CC")
                .replace("x", "\u24CD")
                .replace("y", "\u24CE")
                .replace("z", "\u24CF")
}