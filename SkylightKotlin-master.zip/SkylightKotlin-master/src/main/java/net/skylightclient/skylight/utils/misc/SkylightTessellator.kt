package net.skylightclient.skylight.utils.misc

import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.BufferBuilder
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.client.renderer.Tessellator
import net.minecraft.client.renderer.vertex.DefaultVertexFormats
import net.minecraft.util.math.AxisAlignedBB
import net.minecraft.util.math.BlockPos
import org.lwjgl.opengl.GL11
import org.lwjgl.opengl.GL32
import org.lwjgl.util.glu.GLU
import org.lwjgl.util.glu.Sphere
import java.awt.Color


class SkylightTessellator private constructor() {
    val mc by lazy { Minecraft.getMinecraft() }

    fun drawBox(blockPos: BlockPos, height: Double, color: Color, sides: Int) =
            drawBox(blockPos.getX().toDouble(), blockPos.getY().toDouble(), blockPos.getZ().toDouble(), 1.0, height, 1.0, color, sides)

    fun drawBox(bb: AxisAlignedBB, check: Boolean, height: Double, color: Color, sides: Int) {
        if (check) {
            drawBox(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, bb.maxY - bb.minY, bb.maxZ - bb.minZ, color, sides)
        } else {
            drawBox(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, height, bb.maxZ - bb.minZ, color, sides)
        }
    }

    fun drawBox(x: Double, y: Double, z: Double, w: Double, h: Double, d: Double, color: Color, sides: Int) {
        val tessellator = Tessellator.getInstance()
        val bufferbuilder = tessellator.buffer
        glColor(color)
        bufferbuilder.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION)
        if (sides and GeometryMasks.Quad.DOWN !== 0) {
            vertex(x + w, y, z, bufferbuilder)
            vertex(x + w, y, z + d, bufferbuilder)
            vertex(x, y, z + d, bufferbuilder)
            vertex(x, y, z, bufferbuilder)
        }
        if (sides and GeometryMasks.Quad.UP !== 0) {
            vertex(x + w, y + h, z, bufferbuilder)
            vertex(x, y + h, z, bufferbuilder)
            vertex(x, y + h, z + d, bufferbuilder)
            vertex(x + w, y + h, z + d, bufferbuilder)
        }
        if (sides and GeometryMasks.Quad.NORTH !== 0) {
            vertex(x + w, y, z, bufferbuilder)
            vertex(x, y, z, bufferbuilder)
            vertex(x, y + h, z, bufferbuilder)
            vertex(x + w, y + h, z, bufferbuilder)
        }
        if (sides and GeometryMasks.Quad.SOUTH !== 0) {
            vertex(x, y, z + d, bufferbuilder)
            vertex(x + w, y, z + d, bufferbuilder)
            vertex(x + w, y + h, z + d, bufferbuilder)
            vertex(x, y + h, z + d, bufferbuilder)
        }
        if (sides and GeometryMasks.Quad.WEST !== 0) {
            vertex(x, y, z, bufferbuilder)
            vertex(x, y, z + d, bufferbuilder)
            vertex(x, y + h, z + d, bufferbuilder)
            vertex(x, y + h, z, bufferbuilder)
        }
        if (sides and GeometryMasks.Quad.EAST !== 0) {
            vertex(x + w, y, z + d, bufferbuilder)
            vertex(x + w, y, z, bufferbuilder)
            vertex(x + w, y + h, z, bufferbuilder)
            vertex(x + w, y + h, z + d, bufferbuilder)
        }
        tessellator.draw()
    }

    fun drawLine(posx: Double, posy: Double, posz: Double, posx2: Double, posy2: Double, posz2: Double, color: Color) {
        GlStateManager.glLineWidth(1.0f)
        val tessellator = Tessellator.getInstance()
        val bufferbuilder = tessellator.buffer
        glColor(color)
        bufferbuilder.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION)
        vertex(posx, posy, posz, bufferbuilder)
        vertex(posx2, posy2, posz2, bufferbuilder)
        tessellator.draw()
    }

    fun drawSphere(x: Double, y: Double, z: Double, size: Float, slices: Int, stacks: Int) {
        val s = Sphere()
        GlStateManager.glLineWidth(1.2f)
        s.drawStyle = GLU.GLU_SILHOUETTE
        GlStateManager.pushMatrix()
        GlStateManager.translate(x - mc.getRenderManager().viewerPosX, y - mc.getRenderManager().viewerPosY, z - mc.getRenderManager().viewerPosZ)
        s.draw(size, slices, stacks)
        GlStateManager.popMatrix()
    }

    fun drawBorderedRect(x: Double, y: Double, x1: Double, y1: Double, lineWidth: Float, inside: Color, border: Color) {
        val tessellator = Tessellator.getInstance()
        val bufferbuilder = tessellator.buffer
        glColor(inside)
        bufferbuilder.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION)
        bufferbuilder.pos(x, y1, 0.0).endVertex()
        bufferbuilder.pos(x1, y1, 0.0).endVertex()
        bufferbuilder.pos(x1, y, 0.0).endVertex()
        bufferbuilder.pos(x, y, 0.0).endVertex()
        tessellator.draw()
        glColor(border)
        GlStateManager.glLineWidth(lineWidth)
        bufferbuilder.begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION)
        bufferbuilder.pos(x, y, 0.0).endVertex()
        bufferbuilder.pos(x, y1, 0.0).endVertex()
        bufferbuilder.pos(x1, y1, 0.0).endVertex()
        bufferbuilder.pos(x1, y, 0.0).endVertex()
        bufferbuilder.pos(x, y, 0.0).endVertex()
        tessellator.draw()
    }

    private fun glColor(color: Color) =
            GlStateManager.color(color.red/255.0f,color.green/255.0f,color.blue/255.0f,color.alpha /255.0f)

    private fun vertex(x: Double, y: Double, z: Double, bufferbuilder: BufferBuilder) =
            bufferbuilder.pos(x - mc.getRenderManager().viewerPosX, y - mc.getRenderManager().viewerPosY, z - mc.getRenderManager().viewerPosZ).endVertex()

    private fun getBoundingBox(bp: BlockPos, width: Double, height: Double, depth: Double): AxisAlignedBB {
        val x = bp.getX().toDouble()
        val y = bp.getY().toDouble()
        val z = bp.getZ().toDouble()
        return AxisAlignedBB(x, y, z, x + width, y + height, z + depth)
    }

    fun prepare() {
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST)
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ZERO, GL11.GL_ONE)
        GlStateManager.shadeModel(GL11.GL_SMOOTH)
        GlStateManager.depthMask(false)
        GlStateManager.enableBlend()
        GlStateManager.disableDepth()
        GlStateManager.disableTexture2D()
        GlStateManager.disableLighting()
        GlStateManager.disableCull()
        GlStateManager.enableAlpha()
        GL11.glEnable(GL11.GL_LINE_SMOOTH)
        GL11.glEnable(GL32.GL_DEPTH_CLAMP)
    }

    fun release() {
        GL11.glDisable(GL32.GL_DEPTH_CLAMP)
        GL11.glDisable(GL11.GL_LINE_SMOOTH)
        GlStateManager.enableAlpha()
        GlStateManager.enableCull()
        GlStateManager.enableLighting()
        GlStateManager.enableTexture2D()
        GlStateManager.enableDepth()
        GlStateManager.disableBlend()
        GlStateManager.depthMask(true)
        GlStateManager.glLineWidth(1.0f)
        GlStateManager.shadeModel(GL11.GL_FLAT)
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_DONT_CARE)
    }

    companion object {
        val INSTANCE by lazy { SkylightTessellator() }
    }
}
