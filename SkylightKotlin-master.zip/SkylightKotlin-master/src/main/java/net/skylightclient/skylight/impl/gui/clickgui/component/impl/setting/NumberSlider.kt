package net.skylightclient.skylight.impl.gui.clickgui.component.impl.setting

import net.skylightclient.skylight.api.setting.NumberSetting
import net.skylightclient.skylight.impl.gui.clickgui.component.SettingButton
import java.awt.Color

open class NumberSlider <T : NumberSetting<*>> (
        value: T,
        posX: Double,
        posY: Double,
        width: Double,
        height: Double
) : SettingButton <T> (
        value,
        posX,
        posY,
        width,
        height
) {
    override var dragging: Boolean = false

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {
        val hovering = mouseX in posX..width && mouseY in posY..height

        tessellator.drawBorderedRect(
                posX,
                posY,
                width,
                height,
                0F,
                Color(if (hovering) 100 else 0),
                Color(if (hovering) 100 else 0)
        )
        tessellator.drawBorderedRect(
                posX+setting.value.toDouble()-3,
                posY-3,
                posX+setting.value.toDouble()+3,
                posY+tessellator.mc.fontRenderer.FONT_HEIGHT+3,
                3F,
                Color(if (hovering) 255 else 170),
                Color(if (hovering) 255 else 180)
        )
    }

    override fun drawSelf(mouseX: Int, mouseY: Int, partialTicks: Float) {}

    override fun onPress(mouseButton: Int) {

    }

    override fun onHover(mouseX: Int, mouseY: Int) {

    }

    override fun onRelease(mouseButton: Int) {

    }

    override fun initialize() {

    }
}