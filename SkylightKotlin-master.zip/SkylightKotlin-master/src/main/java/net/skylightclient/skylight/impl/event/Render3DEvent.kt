package net.skylightclient.skylight.impl.event

import net.skylightclient.skylight.api.event.Event

class Render3DEvent(val partialTicks: Float) : Event()