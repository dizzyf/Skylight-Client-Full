package net.skylightclient.skylight.api.setting

class DoubleSetting(
        name: String,
        id: String,
        value: Double,
        min: Double,
        max: Double
) : NumberSetting <Double> (
        name,
        id,
        value,
        min,
        max
)