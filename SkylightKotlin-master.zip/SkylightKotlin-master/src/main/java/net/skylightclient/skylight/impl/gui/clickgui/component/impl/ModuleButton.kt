package net.skylightclient.skylight.impl.gui.clickgui.component.impl

import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.setting.*
import net.skylightclient.skylight.impl.gui.clickgui.component.GUIComponent
import net.skylightclient.skylight.impl.gui.clickgui.component.SettingButton
import net.skylightclient.skylight.impl.gui.clickgui.component.impl.setting.*

class ModuleButton(
        val module: Module,
        override var posX: Double,
        override var posY: Double,
        override val width: Double,
        override val height: Double
) : GUIComponent {
    private val settings = ArrayList<SettingButton<*>>()

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {

    }

    override fun drawSelf(mouseX: Int, mouseY: Int, partialTicks: Float) {

    }

    override fun onHover(mouseX: Int, mouseY: Int) {

    }

    override fun onPress(mouseButton: Int) {

    }

    override fun onRelease(mouseButton: Int) {

    }

    override var draggable: Boolean = false
    override var visible: Boolean = false
    override var dragging: Boolean = false

    override fun initialize() {
        var x = 0.0
        var y = 0.0
        var w = 0.0
        var h = 0.0

        for (setting in module.settingList) {
            settings.add(
                    when (setting) {
                        is BooleanSetting -> {
                            BooleanBox(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        is ColorSetting -> {
                            ColorPalette(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        is KeySetting -> {
                            BindingBox(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        is ModeSetting -> {
                            ModeMenu(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        is NumberSetting<*> -> {
                            NumberSlider(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        is ParentSetting -> {
                            ParentPack(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        is TextSetting -> {
                            TextBox(
                                    setting,
                                    x,
                                    y,
                                    w,
                                    h
                            )
                        }

                        else -> throw IllegalStateException("Unknown Type: ${setting::class.simpleName}")
                    }.apply {
                        this.initialize()
                    }
            )

            x += 0
            y += 0
            w += 0
            h += 0
        }
    }
}