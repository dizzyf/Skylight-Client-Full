package net.skylightclient.skylight.impl.gui.clickgui.component.impl.setting

import net.skylightclient.skylight.api.setting.TextSetting
import net.skylightclient.skylight.impl.gui.clickgui.component.SettingButton

class TextBox(
        setting: TextSetting,
        posX: Double,
        posY: Double,
        width: Double,
        height: Double
) : SettingButton<TextSetting>(
        setting,
        posX,
        posY,
        width,
        height
) {
    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {

    }

    override fun drawSelf(mouseX: Int, mouseY: Int, partialTicks: Float) {

    }

    override fun onHover(mouseX: Int, mouseY: Int) {

    }

    override fun onPress(mouseButton: Int) {

    }

    override fun onRelease(mouseButton: Int) {

    }

    override var dragging: Boolean
        get() = false
        set(v) {}

    override fun initialize() {

    }
}