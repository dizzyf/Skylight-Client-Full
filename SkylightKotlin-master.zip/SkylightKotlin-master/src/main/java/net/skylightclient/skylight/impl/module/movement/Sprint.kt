package net.skylightclient.skylight.impl.module.movement

import net.skylightclient.skylight.api.event.EventListener
import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.api.setting.ModeSetting
import net.skylightclient.skylight.impl.event.UpdateEvent

object Sprint : Module(
        "Sprint",
        "Sprint",
        "Sprints. Obviously.",
        ModuleCategory.Movement
) {
    private var mode by register(
            ModeSetting(
                    "Mode",
                    "$name.Mode",
                    arrayListOf(
                            "Rage",
                            "Legit",
                            "Continuous"
                    )
    ))

    val onUpdate = EventListener(
            UpdateEvent::class.java,
            {
                if (isNullSafe())
                    when (mode) {
                        "Rage" -> {
                            mc.player.isSprinting =
                                    mc.gameSettings.keyBindForward.isKeyDown ||
                                            mc.gameSettings.keyBindLeft.isKeyDown ||
                                            mc.gameSettings.keyBindBack.isKeyDown ||
                                            mc.gameSettings.keyBindRight.isKeyDown
                        }

                        "Legit" -> {
                            mc.player.isSprinting = mc.gameSettings.keyBindForward.isKeyDown
                        }

                        "Continuous" -> {
                            mc.player.isSprinting = true
                        }
                    }
                true
            },
            this
    )
}