package net.skylightclient.skylight.impl.module

import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory

object DummyModule : Module("DummyModule", "DummyModule", "A Dummy Module", ModuleCategory.Misc)