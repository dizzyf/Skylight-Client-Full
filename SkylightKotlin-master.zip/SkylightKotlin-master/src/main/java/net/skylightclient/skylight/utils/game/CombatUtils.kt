package net.skylightclient.skylight.utils.game

import net.minecraft.client.Minecraft
import net.minecraft.entity.player.EntityPlayer
import net.skylightclient.skylight.utils.players.Friends

object CombatUtils {
    private val mc by lazy { Minecraft.getMinecraft() }

    fun getBestTarget(range: Double, wallRange: Double): EntityPlayer {
        return mc.world.playerEntities.stream()
                .filter { it != mc.player }
                .filter { !Friends.isFriend(it) }
                .filter { mc.player.getDistance(it) < if (mc.player.canEntityBeSeen(it)) range else wallRange }
                .min(Comparator.comparing
                <EntityPlayer, Float> {
                    mc.player.getDistance(it)
                }).orElse(null)
    }
}