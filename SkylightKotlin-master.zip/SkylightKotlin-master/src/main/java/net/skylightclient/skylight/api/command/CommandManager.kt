package net.skylightclient.skylight.api.command

import net.minecraft.client.Minecraft
import net.minecraftforge.client.event.ClientChatEvent
import net.minecraftforge.common.MinecraftForge
import net.minecraftforge.fml.common.Mod
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent
import net.skylightclient.skylight.impl.command.*
import net.skylightclient.skylight.utils.misc.Initializable

@Mod.EventBusSubscriber
object CommandManager : Initializable {
    private var prefix = "@"

    private val commands = arrayListOf(
            ActiveCommand,
            SetCommand(),
            SettingsCommand,
            ToggleCommand
    )

    @SubscribeEvent
    fun onChat(event: ClientChatEvent) {
        for (s: String in arrayOf(
                ".",
                "!",
                ",",
                "/"
        )) if (event.message.startsWith(s)) return

        if (!event.message.startsWith(prefix))
            return

        event.isCanceled = true
        Minecraft.getMinecraft().ingameGUI.chatGUI.addToSentMessages(event.message)

        parse(event.message)
    }

    private fun parse(text: String) =
            with (text.replaceFirst(prefix, "")
                    .split(" ")
            ) {
                if (this.isNotEmpty())
                    for (command in commands)
                        for (alias: String in command.aliases())
                            if (alias.equals(this[0], true))
                                command.exec(this)
                    }

    override fun initialize() =
            MinecraftForge.EVENT_BUS.register(this)
}