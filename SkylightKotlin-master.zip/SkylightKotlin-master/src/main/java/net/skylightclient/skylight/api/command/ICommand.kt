package net.skylightclient.skylight.api.command

interface ICommand {
    fun aliases(): ArrayList<String>
    fun description(): String
    fun usage(): String
    fun exec(args: List<String>)
}