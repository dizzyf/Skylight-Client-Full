package net.skylightclient.skylight.impl.event

import net.skylightclient.skylight.api.event.Event

class UpdateEvent : Event() {
    override var cancelled: Boolean = false
    set(v) = Unit // makes it so you can't cancel an update event.
}