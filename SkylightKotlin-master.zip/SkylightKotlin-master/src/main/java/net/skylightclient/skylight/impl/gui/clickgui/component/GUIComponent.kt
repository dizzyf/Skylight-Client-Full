package net.skylightclient.skylight.impl.gui.clickgui.component

import net.minecraft.util.ResourceLocation
import net.skylightclient.skylight.impl.module.ui.ClickGUIMod
import net.skylightclient.skylight.utils.misc.Initializable
import net.skylightclient.skylight.utils.misc.SkylightTessellator
import java.awt.Color

interface GUIComponent : Initializable {
    fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float)
    @Deprecated("Useless") fun drawSelf(mouseX: Int, mouseY: Int, partialTicks: Float)
    fun onHover(mouseX: Int, mouseY: Int)
    fun onPress(mouseButton: Int)
    fun onRelease(mouseButton: Int)

    var draggable: Boolean
    var visible: Boolean
    var dragging: Boolean

    var posX: Double
    var posY: Double
    val width: Double
    val height: Double

    val tessellator: SkylightTessellator
        get() = SkylightTessellator.INSTANCE

    val textColor: Color
        get() = ClickGUIMod.textColor.getAsColor()
    val labelColor: Color
        get() = ClickGUIMod.labelColor.getAsColor()
    val showTooltips: Boolean
        get() = ClickGUIMod.showTooltips
    val rainbow: Boolean
        get() = ClickGUIMod.rainbow

    val colorPicker: ResourceLocation
        get() = ResourceLocation("color_picker.png")
}