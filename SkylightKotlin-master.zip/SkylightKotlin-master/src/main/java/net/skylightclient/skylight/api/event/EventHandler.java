package net.skylightclient.skylight.api.event;

import java.util.ArrayList;
import java.util.function.Function;

@SuppressWarnings("unchecked")
public class EventHandler {
    private static final ArrayList<EventListener<? extends Event>> listeners = new ArrayList<>();

    public static <T extends Event> void register(EventListener<T> listener) { listeners.add(listener); }
//    public static <T extends Event> void unregister(EventListener<T> listener) { listeners.remove(listener); }

    public static <T extends Event> Event dispatch(T event) {
        listeners.stream()
                .filter(
                        it -> it.shouldDispatch(event)
                ).forEach(
                        it -> {
                            if (event.getCancelled())
                                return;
                            event.setCancelled(((Function<T, Boolean>)it.getInvokable()).apply(event));
                        });

        return event;
    }
}
