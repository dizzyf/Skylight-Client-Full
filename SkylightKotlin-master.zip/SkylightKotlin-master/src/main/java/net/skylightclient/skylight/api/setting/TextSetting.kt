package net.skylightclient.skylight.api.setting

class TextSetting(
        name: String,
        id: String,
        value: String
) : Setting <String>(
        name,
        id,
        value
)