package net.skylightclient.skylight.impl.module.combat

import net.minecraft.entity.Entity
import net.minecraft.item.ItemSword
import net.minecraft.util.EnumHand
import net.skylightclient.skylight.api.event.EventListener
import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.api.setting.*
import net.skylightclient.skylight.impl.event.UpdateEvent
import net.skylightclient.skylight.utils.game.CombatUtils

object Aura : Module(
        "Aura",
        "Aura",
        "Hits your opponents with the item in your hand. Bonk!",
        ModuleCategory.Combat
) {
    private var range by register(
            DoubleSetting(
                    "Range",
                    "Aura.Range",
                    5.0,
                    0.0,
                    6.0
            )
    )
    private var wallRange by register(
            DoubleSetting(
                    "WallRange",
                    "Aura.WallRange",
                    3.0,
                    0.0,
                    5.0
            )
    )
    private var swordOnly by register(
            BooleanSetting(
                    "SwordOnly",
                    "Aura.SwordOnly",
                    true
            )
    )
    private val modeSetting = register(
            ModeSetting(
                    "Mode",
                    "Aura.Mode",
                    arrayListOf(
                            "Single",
                            "Jumpy",
                            "Smart"
                    )
            )
    )
    private var mode by modeSetting

    private var autoDelaySetting = register(
            BooleanSetting(
                    "AutoDelay",
                    "Aura.Delay.AutoDelay",
                    true
            )
    ).asChild()
    private var tickDelaySetting = register(
            IntegerSetting(
                    "TickDelay",
                    "Aura.Delay.TickDelay",
                    0,
                    0,
                    20
            )
    ).asChild()
    private var delay by register(
            ParentSetting(
                    "Delay",
                    "Aura.Delay",
                    true,
                    false,
                    listOf(
                            autoDelaySetting,
                            tickDelaySetting
                    )
            )
    )
    private var autoDelay by autoDelaySetting
    private var tickDelay by tickDelaySetting
    private var ticksWaited = 0

    private val onUpdate = EventListener(
            UpdateEvent::class.java,
            {
                if (!isNullSafe())
                    return@EventListener true
                if (swordOnly && mc.player.heldItemMainhand.item !is ItemSword)
                    return@EventListener true
                if (autoDelay && mc.player.getCooledAttackStrength(0F) < 1)
                    return@EventListener true
                else if (ticksWaited <= tickDelay) { ticksWaited++; return@EventListener true } else ticksWaited = 0

                val target = CombatUtils.getBestTarget(
                        range,
                        wallRange
                )
                        target == null ?: return@EventListener true

                hitEntity(target)

                true
            },
            this
    )

    private fun hitEntity(entity: Entity) {
        mc.playerController.attackEntity(mc.player, entity)
        mc.player.swingArm(EnumHand.MAIN_HAND)
    }
}