package net.skylightclient.skylight.api.setting

class BooleanSetting(
        name: String,
        id: String,
        value: Boolean
) : Setting <Boolean> (
        name,
        id,
        value
)