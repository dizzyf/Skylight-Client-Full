package net.skylightclient.skylight.impl.gui.clickgui.component

import net.skylightclient.skylight.api.setting.Setting

abstract class SettingButton <T : Setting<*>> (
        val setting: T,
        override var posX: Double,
        override var posY: Double,
        override val width: Double,
        override val height: Double
) : GUIComponent {
    final override var draggable: Boolean = false
        set(v) = Unit // making the value effectively final
    final override var visible: Boolean
        get() = !setting.child
        set(v) = Unit // making the value effectively final
}