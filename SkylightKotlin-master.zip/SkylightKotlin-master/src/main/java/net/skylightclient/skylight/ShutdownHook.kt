package net.skylightclient.skylight

import net.skylightclient.skylight.api.module.ModuleManager

class ShutdownHook : Thread() {
    override fun run() {
        ModuleManager.saveModules()
    }
}