package net.skylightclient.skylight.impl.event

import net.minecraft.entity.player.EntityPlayer
import net.skylightclient.skylight.api.event.Event

class AttackEvent(val player: EntityPlayer) : Event()