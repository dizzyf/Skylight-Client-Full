package net.skylightclient.skylight.api.mixin.mixins.entity

import net.minecraft.entity.player.EntityPlayer
import net.minecraft.util.DamageSource
import net.skylightclient.skylight.api.event.EventHandler
import net.skylightclient.skylight.impl.event.PlayerDeathEvent
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.Shadow
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(EntityPlayer::class)
object MixinEntityPlayer {
    @Shadow lateinit var displayName: String

    @Inject(method = ["onDeath"], at = [At("HEAD")])
    fun onDeath(src: DamageSource, ci: CallbackInfo) {
        EventHandler.dispatch(PlayerDeathEvent(displayName))
    }
}