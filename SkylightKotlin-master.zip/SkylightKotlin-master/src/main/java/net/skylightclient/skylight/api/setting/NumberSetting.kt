package net.skylightclient.skylight.api.setting

import kotlin.reflect.KProperty

open class NumberSetting <T : Number> (
        name: String,
        id: String,
        value: T,
        val min: T,
        val max: T
) : Setting <T> (
        name,
        id,
        value
) {
    override operator fun setValue(thisRef: Any, kprop: KProperty<*>, newVal: T) {
        onValueOverride(newVal)
        value = when {
            newVal.toDouble() < min.toDouble() -> min
            newVal.toDouble() > max.toDouble() -> max
            else -> newVal
        }
    }
}