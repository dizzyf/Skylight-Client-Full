package net.skylightclient.skylight.impl.module.misc

import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import java.awt.Desktop
import java.net.URI

object AutoRickRoll : Module(
        "AutoRickRoll",
        "AutoRickRoll",
        "Dupes your items",
        ModuleCategory.Misc
) {
    override fun onEnable() {
        Desktop.getDesktop().browse(URI.create("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        active = false
    }
}