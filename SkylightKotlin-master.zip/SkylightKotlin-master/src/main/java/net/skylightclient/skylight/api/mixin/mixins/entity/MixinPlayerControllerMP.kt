package net.skylightclient.skylight.api.mixin.mixins.entity

import net.minecraft.client.multiplayer.PlayerControllerMP
import net.minecraft.entity.player.EntityPlayer
import net.skylightclient.skylight.api.event.EventHandler
import net.skylightclient.skylight.impl.event.AttackEvent
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(PlayerControllerMP::class)
object MixinPlayerControllerMP {
    @Inject(method = ["attackEntity"], at = [At("HEAD")], cancellable = true)
    fun onAttackEntity(player: EntityPlayer, ci: CallbackInfo) {
        if (EventHandler.dispatch(AttackEvent(player)).cancelled)
            ci.cancel()
    }
}