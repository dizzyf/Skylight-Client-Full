package net.skylightclient.skylight.utils.players

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import net.minecraft.entity.player.EntityPlayer
import net.skylightclient.skylight.utils.misc.FileUtil
import net.skylightclient.skylight.utils.misc.Initializable
import org.json.simple.parser.JSONParser
import java.io.FileReader
import java.util.*
import kotlin.collections.ArrayList

object Friends : Initializable {
    val friendList = ArrayList<UUID>()

    fun isFriend(player: EntityPlayer): Boolean =
            friendList.contains(player.entityUniqueID)

    fun addFriend(player: EntityPlayer) {
        if (!friendList.contains(player.entityUniqueID))
            friendList.add(player.uniqueID)
    }

    fun removeFriend(player: EntityPlayer) {
        friendList.remove(player.uniqueID)
    }

    override fun initialize() {
        val jObj: JsonArray = FileUtil.getJsonElementByPath("Friends.json") ?: return

        for (j: JsonElement in jObj.asIterable())
            friendList.add(UUID.fromString(j.asString))
    }

    fun save() {
        // TODO saving friends
    }
}