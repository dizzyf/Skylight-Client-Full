package net.skylightclient.skylight.impl.command;

import net.skylightclient.skylight.api.command.ICommand;
import net.skylightclient.skylight.api.module.ModuleManager;
import net.skylightclient.skylight.api.setting.*;
import net.skylightclient.skylight.utils.game.ChatUtils;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class SetCommand implements ICommand {
    @NotNull
    @Override public ArrayList<String> aliases() {
        ArrayList<String> returning = new ArrayList<>();

        returning.add("s");
        returning.add("set");
        returning.add("val");
        returning.add("value");

        return returning;
    }

    @NotNull
    @Override public String description() {
        return "Sets a value for a Module.";
    }

    @NotNull
    @Override public String usage() {
        return "TODO";
    }

    @Override public void exec(@NotNull List<String> args) {
        if (args.size() != 4) {
            ChatUtils.INSTANCE.sendChatMessage(
                    "Argument size for command set has to always be 4."
            ); return;
        }

        Setting<?> s = ModuleManager.INSTANCE
                .getModule(args.get(1))
                .getSettingByName(args.get(2));

        if (s == null) {
            ChatUtils.INSTANCE.sendChatMessage(
                    "Could not find the setting " +
                            args.get(2) +
                            " for Module " +
                            args.get(1)
            ); return;
        }

        switch (s.getClass().getSimpleName()) {
            case "BooleanSetting":
                ((BooleanSetting)s).setVal(Boolean.getBoolean(args.get(3)));
                ChatUtils.INSTANCE.sendChatMessage("Set value " + s.getId() + " to " + s.getVal());
                break;
            case "DoubleSetting":
                ((DoubleSetting)s).setVal(Double.parseDouble(args.get(3)));
                ChatUtils.INSTANCE.sendChatMessage("Set value " + s.getId() + " to " + s.getVal());
                break;
            case "ModeSetting":
                if (args.get(3).equalsIgnoreCase("next"))
                    ((ModeSetting)s).cycle(false);
                else if (args.get(3).equalsIgnoreCase("last"))
                    ((ModeSetting)s).cycle(true);
                ChatUtils.INSTANCE.sendChatMessage("Set value " + s.getId() + " to " + s.getVal());
                break;
            case "IntegerSetting":
                ((IntegerSetting)s).setVal(Integer.parseInt(args.get(3)));
                ChatUtils.INSTANCE.sendChatMessage("Set value " + s.getId() + " to " + s.getVal());
                break;
            case "TextSetting":
                ((TextSetting)s).setVal(args.get(3));
                ChatUtils.INSTANCE.sendChatMessage("Set value " + s.getId() + " to " + s.getVal());
                break;
        }
    }
}
