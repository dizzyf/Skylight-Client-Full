package net.skylightclient.skylight.impl.module.ui

import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.api.setting.BooleanSetting
import net.skylightclient.skylight.api.setting.ColorSetting
import net.skylightclient.skylight.impl.gui.clickgui.ClickGUI

object ClickGUIMod : Module(
        "ClickGUI",
        "ClickGUI",
        "Opens up the GUI. *Click!*",
        ModuleCategory.UI
) {
    val textColor = register(ColorSetting("TextColor", "ClickGUI.TextColor", 195, 38, 206, 100))
    val labelColor = register(ColorSetting("BackgroundColor", "ClickGUI.BackgroundColor", 84, 187, 255, 75))

    val showTooltips by register(BooleanSetting("ModuleTooltips", "ClickGUI.ShowTooltips", true))
    val rainbow by register(BooleanSetting("Rainbow", "ClickGUI.Rainbow", false))

    override fun onEnable() =
            mc.displayGuiScreen(ClickGUI)

//    val onKeybindInput = EventListener() TODO keybind listener for binds
}