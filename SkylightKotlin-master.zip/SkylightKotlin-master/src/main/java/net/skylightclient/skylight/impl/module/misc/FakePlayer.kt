package net.skylightclient.skylight.impl.module.misc

import com.mojang.authlib.GameProfile
import net.minecraft.client.entity.EntityOtherPlayerMP
import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.api.setting.BooleanSetting
import net.skylightclient.skylight.api.setting.TextSetting
import java.util.*

object FakePlayer : Module("FakePlayer", "FakePlayer", "Creates a Fake Player", ModuleCategory.Misc) {
    val playerName = register(
            TextSetting(
                    "Name",
                    "FakePlayer.Name",
                    "pieter_ams"
            )
    )
    val reset = register(
            BooleanSetting(
                    "Name",
                    "FakePlayer.Name",
                    false
            ).apply {
                this.onValueOverride = {
                    if (it) onDisable()
                    else onEnable()

                    this.value = false
                }
            }
    )
    private lateinit var fakePlayer: EntityOtherPlayerMP
    override fun onEnable() {
        fakePlayer = EntityOtherPlayerMP(mc.world, GameProfile(UUID.randomUUID(), playerName.getVal()))
        mc.world.addEntityToWorld(fakePlayer.entityId, fakePlayer)
        fakePlayer.attemptTeleport(mc.player.posX, mc.player.posY, mc.player.posZ)
    }

    override fun onDisable() { mc.world.removeEntityFromWorld(fakePlayer.entityId) }
}