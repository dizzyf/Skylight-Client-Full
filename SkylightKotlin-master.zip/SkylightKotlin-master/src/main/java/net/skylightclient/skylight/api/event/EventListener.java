package net.skylightclient.skylight.api.event;

import net.skylightclient.skylight.api.module.Module;

import java.util.function.Function;

public class EventListener<T extends Event> {
    private final Class<T> type;
    private final Function<T, Boolean> invokable;
    private final Module host;

    public EventListener(Class<T> type, Function<T, Boolean> invokable, Module host) {
        this.type = type;
        this.invokable = invokable;
        this.host = host;

        EventHandler.register(this);
    }

    public Function<T, Boolean> getInvokable() {
        return invokable;
    }
    public boolean shouldDispatch(Event event) {
        return host.getActive() && type.isAssignableFrom(event.getClass());
    }
}
