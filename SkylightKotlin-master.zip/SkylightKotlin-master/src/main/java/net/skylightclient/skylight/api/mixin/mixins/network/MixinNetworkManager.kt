package net.skylightclient.skylight.api.mixin.mixins.network

import io.netty.channel.ChannelHandlerContext
import net.minecraft.network.NetworkManager
import net.minecraft.network.Packet
import net.skylightclient.skylight.api.event.EventHandler
import net.skylightclient.skylight.impl.event.PacketEvent
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(NetworkManager::class)
object MixinNetworkManager {
    @Inject(method = ["channelRead0"], at = [At("HEAD")], cancellable = true)
    fun onChannelRead0(channelHandlerContext: ChannelHandlerContext, packet: Packet<*>, ci: CallbackInfo) {
        if (EventHandler.dispatch(PacketEvent.Read(packet)).cancelled)
            ci.cancel()
    }

    @Inject(method = ["sendPacket"], at = [At("HEAD")], cancellable = true)
    fun onSendPacket(packet: Packet<*>, ci: CallbackInfo) {
        if (EventHandler.dispatch(PacketEvent.Write(packet)).cancelled)
            ci.cancel()
    }
}