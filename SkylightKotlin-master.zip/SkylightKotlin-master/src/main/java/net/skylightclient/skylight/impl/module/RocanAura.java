package net.skylightclient.skylight.impl.module;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumHand;
import net.skylightclient.skylight.api.event.EventListener;
import net.skylightclient.skylight.api.module.Module;
import net.skylightclient.skylight.api.module.ModuleCategory;
import net.skylightclient.skylight.api.setting.*;
import net.skylightclient.skylight.impl.event.PlayerDeathEvent;
import net.skylightclient.skylight.impl.event.UpdateEvent;
import net.skylightclient.skylight.utils.players.Friends;

import java.util.Arrays;
import java.util.Comparator;

@SuppressWarnings("unused")
public class RocanAura extends Module {
    private Minecraft mc; // Kotlin thing

    public final DoubleSetting range = register(
            new DoubleSetting("Range", "RocanAura.Range", 5.0, 0.0, 6.0)
    );

    public final DoubleSetting wallRange = register(
            new DoubleSetting("WallRange", "RocanAura.WallRange", 3.5, 0.0, 5.0)
    );

    public final BooleanSetting hitFriends = register(
            new BooleanSetting("IgnoreFriends", "RocanAura.IgnoreFriends", true)
    );

    public final BooleanSetting swordOnly = register(
            new BooleanSetting("SwordOnly", "RocanAura.SwordOnly", true)
    );

    public IntegerSetting tickDelay;
    public BooleanSetting tpsSync;
    public final ParentSetting autoDelay = register(
            new ParentSetting("Delay", "RocanAura.Delay", true, false, Arrays.<Setting<?>>asList(
                    tickDelay = new IntegerSetting("TickDelay", "RocanAura.Delay.TickDelay", 0, 0, 20),
                    tpsSync = new BooleanSetting("TPSSync", "RocanAura.Delay.TPSSync", false)
            ))
    );

    private EntityPlayer target;

    private boolean hasDoneAnything;
    private boolean firstRun;

    private int ticksWaited;

    public RocanAura() {
        super("KillAura", "RocanAura", "Kill aura 4 max by reap <3", ModuleCategory.Combat);

        mc = getMc();
    }

    @Override
    public void onEnable() {
        target = null;

        hasDoneAnything = false;
        firstRun = true;

        ticksWaited = 0;
    }

    private final EventListener<UpdateEvent> onTick = new EventListener<>(
            UpdateEvent.class,
            event -> {
                if (!isNullSafe())
                    return true;

                hasDoneAnything = false;

                if (swordOnly.getVal() && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword))
                    return true;

                if (!firstRun) {
                    if (!autoDelay.getVal()) {
                        if (ticksWaited < tickDelay.getVal()) {
                            ticksWaited++;
                            return true;
                        } else ticksWaited = 0;
                    } else {
                        if (mc.player.getCombatTracker().getCombatDuration()>0) return true;
                    }
                }

                target = findClosestTarget(!hitFriends.getVal());

                if (target == null)
                    return true;

                mc.playerController.attackEntity(mc.player, target);
                mc.player.swingArm(EnumHand.MAIN_HAND);
                hasDoneAnything = true;

                if (firstRun) firstRun = false;

                return true;
            },
            this
    );

    private final EventListener<PlayerDeathEvent> onPlayerDeath = new EventListener<>(
            PlayerDeathEvent.class,
            event -> {
                if (hasDoneAnything && event.getPlayerName().equals(target.getDisplayNameString())) {
                    mc.player.sendChatMessage("I Just Killed " + target.getDisplayNameString() + " By Rocan Aura" + (firstRun ? " in one hit!" : "!"));// TODO AutoEZ/AutoGG logic here
                }

                return true;
            },
            this
    );

    private EntityPlayer findClosestTarget(boolean ignoreFriends) {
        return mc.world.playerEntities.stream()
                .filter(it -> it != mc.player)
                .filter(it -> mc.player.getDistance(it) < (mc.player.canEntityBeSeen(it) ? range.getVal() : wallRange.getVal()))
                .filter(it -> !ignoreFriends || Friends.INSTANCE.isFriend(it))
                .min(Comparator.comparing(it -> mc.player.getDistance(it)))
                .orElse(null);
    }
}
