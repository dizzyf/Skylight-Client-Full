package net.skylightclient.skylight.impl.gui.clickgui.component.impl

import net.skylightclient.skylight.api.module.ModuleManager
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.impl.gui.clickgui.component.GUIComponent

class Category(
        val category: ModuleCategory,
        override var posX: Double,
        override var posY: Double,
        override val width: Double,
        override val height: Double
) : GUIComponent {
    val modules = ArrayList<ModuleButton>()

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {
        for (module in modules) {
            if (dragging) {
                module.posX += mouseX - lastMouseX
                module.posY += mouseY - lastMouseY
            }

            module.drawScreen(mouseX, mouseY, partialTicks)

            if (
                    mouseX > module.posX &&
                    mouseX < module.posX + module.width &&
                    mouseY > module.posY &&
                    mouseY < module.posY + module.height
            ) module.onHover(mouseX, mouseY)
        }

        lastMouseX = mouseX
        lastMouseY = mouseY
    }

    override fun drawSelf(mouseX: Int, mouseY: Int, partialTicks: Float) {
        for (module in modules)
            module.drawSelf(mouseX, mouseY, partialTicks)
    }

    override fun onHover(mouseX: Int, mouseY: Int) {
        hovering = true
    }

    override fun onPress(mouseButton: Int) {
        dragging = hovering
        for (module in modules)
            module.onPress(mouseButton)
    }

    override fun onRelease(mouseButton: Int) {
        dragging = false
        for (module in modules)
            module.onRelease(mouseButton)
    }

    override var draggable = true
    override var visible = true
    override var dragging = false

    var hovering = false
    var lastMouseX = -1
    var lastMouseY = -1

    override fun initialize() {
        var x = 0.0
        var y = 0.0
        var w = 0.0
        var h = 0.0

        for (module in ModuleManager.modules) {
            modules.add(ModuleButton(module, x, y, w, h))

            x += 0
            y += 0
            w += 0
            h += 0
        }

        ModuleManager.modules.stream()
                .filter { it.category == category }
                .forEach {
                    modules.add(
                            ModuleButton(
                                    it,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0
                            ).apply { this.initialize() }
                    )
                }
    }
}