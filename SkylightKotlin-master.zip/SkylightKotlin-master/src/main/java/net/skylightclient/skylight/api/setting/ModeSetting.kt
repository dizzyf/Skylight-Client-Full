package net.skylightclient.skylight.api.setting

class ModeSetting (
        name: String,
        id: String,
        val values: ArrayList<String>
) : Setting<String>(
        name,
        id,
        values[0]
) {
    var savedSpot: Int = 0

    fun cycle(reverse: Boolean) {
        value = values [
                if (reverse)
                    if (savedSpot == 0) {
                        savedSpot = values.size-1
                        values.size-1
                    } else savedSpot--
                else if (savedSpot == values.size-1) {
                    savedSpot = 0
                    0
                } else savedSpot++
        ]
    }

    fun setToSpot(spot: Int) {
        value = values [
                when {
                    spot > values.size-1 -> {
                        savedSpot = values.size-1
                        values.size-1
                    }
                    spot < 0 -> {
                        savedSpot = 0
                        0
                    }
                    else -> {
                        savedSpot = spot
                        spot
                    }
                }
        ]
    }
}