package net.skylightclient.skylight.api.setting

import kotlin.reflect.KProperty

/**
 * @author Reap
 * @since 11/15/2020
 *
 * @param name: the name for the setting
 * @param id: the id for the setting
 * @param value: the value for the setting
 */
open class Setting <T> (
        val name: String,
        val id: String,
        var value: T
) {
    /**
     * runs when we update value (only when we are using it outside of the setting package)
     */
    var onValueOverride: (T) -> Unit = {}

    /**
     * declares if the setting has a parent, will be used to not show the setting as an independent one but only as a chile
     */
    var child = false
        private set

    /**
     * returns value, can also be used in delegation
     */
    open operator fun getValue(thisRef: Any, kprop: KProperty<*>): T = value
    fun getVal(): T = value

    /**
     * sets value, can also be used in delegation
     */
    open operator fun setValue(thisRef: Any, kprop: KProperty<*>, newVal: T) =
            onValueOverride(newVal).also { value = newVal }
    fun setVal(newVal: T) = onValueOverride(newVal).also { value = newVal }

    /**
     * @return this setting as a child
     */
    fun asChild(): Setting <T> = this.apply {
        this.child = true
    }
}