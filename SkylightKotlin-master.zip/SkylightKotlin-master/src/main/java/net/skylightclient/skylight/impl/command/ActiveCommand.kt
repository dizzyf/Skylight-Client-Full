package net.skylightclient.skylight.impl.command

import net.skylightclient.skylight.api.command.ICommand
import net.skylightclient.skylight.api.module.ModuleManager
import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.utils.game.ChatUtils

object ActiveCommand : ICommand {
    override fun aliases(): ArrayList<String> = arrayListOf(
            "active"
    )
    override fun description(): String = "Shows all the active Modules."
    override fun usage(): String = aliases().toString()

    override fun exec(args: List<String>) {
        var msg = ""

        for (module: Module in ModuleManager.activeModules())
            msg += "${module.id}, "

        if (msg.isEmpty())
            return

        ChatUtils.sendChatMessage(msg)
    }
}
