package net.skylightclient.skylight.impl.module.render

import net.minecraft.potion.Potion
import net.minecraft.potion.PotionEffect
import net.skylightclient.skylight.api.event.EventListener
import net.skylightclient.skylight.api.module.Module
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.impl.event.UpdateEvent
import net.skylightclient.skylight.utils.misc.Key

object Fullbright : Module(
        "Fullbright",
        "Fullbright",
        "Makes your game fully bright",
        ModuleCategory.Render
) {
    private val effect = PotionEffect(Potion.getPotionById(16), Int.MAX_VALUE)

    val onUpdate = EventListener(
            UpdateEvent::class.java,
            {
                if (isNullSafe())
                    mc.player.addPotionEffect(effect)
                true
            },
            this
    )

    override fun onDisable() {
        if (isNullSafe())
            mc.player.removePotionEffect(effect.potion)
    }
}