package net.skylightclient.skylight.api.event

import net.minecraftforge.client.event.RenderGameOverlayEvent
import net.minecraftforge.client.event.RenderWorldLastEvent
import net.minecraftforge.common.MinecraftForge
import net.minecraftforge.fml.common.Mod
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent
import net.minecraftforge.fml.common.gameevent.TickEvent
import net.skylightclient.skylight.impl.event.Render3DEvent
import net.skylightclient.skylight.impl.event.RenderOverlayEvent
import net.skylightclient.skylight.impl.event.UpdateEvent
import net.skylightclient.skylight.utils.misc.Initializable

@Mod.EventBusSubscriber
object EventProcessor : Initializable {
    @SubscribeEvent
    fun onTick(event: TickEvent.ClientTickEvent) {
        EventHandler.dispatch(UpdateEvent())
    }

    @SubscribeEvent
    fun onRenderGame(event: RenderWorldLastEvent) {
        EventHandler.dispatch(Render3DEvent(event.partialTicks))
    }

    @SubscribeEvent
    fun onRenderOverlay(event: RenderGameOverlayEvent) {
        EventHandler.dispatch(RenderOverlayEvent(event.partialTicks))
    }

    override fun initialize() =
            MinecraftForge.EVENT_BUS.register(this)
}