package net.skylightclient.skylight.api.setting

import java.awt.Color

class ColorSetting(
        name: String,
        id: String,
        value: Int,
        var value2: Int,
        var value3: Int,
        var alpha: Int
) : NumberSetting <Int> (
        name,
        id,
        value,
        0,
        255
) {
    fun getAsColor(): Color = Color(value, value2, value3, alpha)
}