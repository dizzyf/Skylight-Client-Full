package net.skylightclient.skylight.impl.command

import net.skylightclient.skylight.api.command.ICommand
import net.skylightclient.skylight.api.module.ModuleManager
import net.skylightclient.skylight.impl.module.DummyModule
import net.skylightclient.skylight.utils.game.ChatUtils.sendChatMessage

object SettingsCommand : ICommand {
    override fun aliases(): ArrayList<String> =
            arrayListOf("settings")

    override fun description(): String =
            "Displays all the Settings for a selected Module."

    override fun usage(): String =
            "settings <module>"

    override fun exec(args: List<String>) {
        if (args.size != 2) {
            sendChatMessage(
                    "Argument size for command settings has to always be 2."
            ); return
        }

        val module = ModuleManager.getModule(args[1])

        if (module == DummyModule) {
            sendChatMessage("Could not find module ${args[1]}")
            return
        }

        val settings = module.settingList
        var displayString = "Modules for ${module.name}:\n"

        for (setting in settings)
            displayString += "${setting.name},\n"

        sendChatMessage(displayString)
    }
}