package net.skylightclient.skylight.impl.event

import net.skylightclient.skylight.api.event.Event

class RenderOverlayEvent(val partialTicks: Float) : Event()