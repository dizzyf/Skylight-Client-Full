package net.skylightclient.skylight.impl.gui.clickgui

import net.minecraft.client.gui.GuiScreen
import net.skylightclient.skylight.api.module.ModuleCategory
import net.skylightclient.skylight.impl.gui.clickgui.component.impl.Category
import net.skylightclient.skylight.utils.game.ChatUtils
import net.skylightclient.skylight.utils.misc.Initializable

object ClickGUI : GuiScreen(), Initializable {
    private val categories: ArrayList<Category> = ArrayList()

    override fun mouseClicked(mouseX: Int, mouseY: Int, mouseButton: Int) {
        ChatUtils.sendChatMessage("Clicked Mouse!")
    }

    override fun mouseReleased(mouseX: Int, mouseY: Int, state: Int) {

    }

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {

    }

    override fun initialize() {
        var x = 0.0
        var y = 0.0
        var w = 0.0
        var h = 0.0

        for (cat: ModuleCategory in ModuleCategory.values()) {
            categories.add(
                    Category(
                            cat,
                            x,
                            y,
                            w,
                            h
                    ).apply {
                        this.initialize()
                    }
            )

            x += 0
            y += 0
            w += 0
            h += 0
            // TODO calc size
        }
    }
}