﻿using Skylight_Installer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skylight_Installer
{
    public partial class sex : Form
    {
        public sex()
        {
            InitializeComponent();
        }

        private void checkonline()
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (client.OpenRead("https://google.com/")) //checking if google is online so the cheats DLL can be downloaded.
                    {
                        label1.ForeColor = Color.Green;
                        label1.Text = ("online");
                    }
                }
            }
            catch
            {
                label1.ForeColor = Color.Red; //if it does not get a response (This means the user is offline or google is down for some reason) it will Exit the application, you can stop this by removing "Application.Exit();"
                label1.Text = ("offline");
                Application.Exit();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string HWID;
            HWID = System.Security.Principal.WindowsIdentity.GetCurrent().User.Value; //Changing the variable "HWID (String)" to the WindowsIdentity Value, you can use any other forms of HWID, you can even use MAC/IP (Not recommended)
            textBox1.Text = HWID;
            textBox1.ReadOnly = true;
            checkonline();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            checkonline();
            WebClient wb = new WebClient();
            string HWIDLIST = wb.DownloadString("https://pastebin.com/raw/CaFnPshN");
            if (HWIDLIST.Contains(textBox1.Text))
            {
                this.Hide();
                fornite sex = new fornite();
                sex.Show();
                MessageBox.Show("you are beta omg!!!!", "jimbo is sexy", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("you arent beta, dm jimb#0001 on discord if you think you're beta", ":(", MessageBoxButtons.OK);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }
    }
}
