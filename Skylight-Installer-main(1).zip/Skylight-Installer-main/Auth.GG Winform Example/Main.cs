﻿using Skylight_Installer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auth.GG_Winform_Example
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void siticoneRoundedButton1_Click(object sender, EventArgs e)
        {
        }

        private void siticoneControlBox1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void siticoneRoundedButton2_Click(object sender, EventArgs e)
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            checkonline();
            WebClient wb = new WebClient();

            string mainpath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Skylight.jar";
            wb.DownloadFile("https://github.com/fds67dfrsa76dsfagd76sabd76g67dsa/skylight-loader/raw/main/Skylight.jar", mainpath); //both dont work lol
            MessageBox.Show("download successful ", "skylight on top", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
        private void checkonline()
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (client.OpenRead("https://google.com/")) //checking if google is online so the cheats DLL can be downloaded.
                    {
                        label1.ForeColor = Color.Green;
                        label1.Text = ("online");
                    }
                }
            }
            catch
            {
                label1.ForeColor = Color.Red; //if it does not get a response (This means the user is offline or google is down for some reason) it will Exit the application, you can stop this by removing "Application.Exit();"
                label1.Text = ("offline");
                Application.Exit();
            }
        }

        private void siticoneRoundedButton2_Click_1(object sender, EventArgs e)
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            checkonline();
            WebClient wb = new WebClient();

            string mainpath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.minecraft\\mods\\Osiris.dll";
            wb.DownloadFile("https://github.com/jimbo400/HWIDLockTest/raw/main/Osiris.dll", mainpath); //both dont work lol
        }

        private void Main_Load_1(object sender, EventArgs e)
        {
            
        }

        private void siticoneControlBox2_Click(object sender, EventArgs e)
        {

        }

        private void siticoneControlBox1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void siticoneRoundedButton3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void siticoneRoundedButton1_Click_1(object sender, EventArgs e)
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            checkonline();
            WebClient wb = new WebClient();

            string mainpath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.minecraft\\mods\\Skylight.jar";
            wb.DownloadFile("https://github.com/fds67dfrsa76dsfagd76sabd76g67dsa/skylight-loader/raw/main/Skylight.jar", mainpath); //both dont work lol
            MessageBox.Show("download successful ", "skylight on top", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void siticoneRoundedButton4_Click(object sender, EventArgs e)
        {

            sex monkey = new sex();
            this.Hide();
            monkey.Show();
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}